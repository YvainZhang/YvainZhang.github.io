#define _GNU_SOURCE
#include <assert.h>
#include <errno.h>
#include <fcntl.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/epoll.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <unistd.h>
#define PASS(n) puts("{\"lab\":\"" n "\",\"result\":\"PASS\"}")
static void fairness(void) {
    int a[2], b[2];
    assert(pipe2(a, O_NONBLOCK | O_CLOEXEC) == 0 && pipe2(b, O_NONBLOCK | O_CLOEXEC) == 0);
    char hot[128];
    memset(hot, 'A', sizeof(hot));
    assert(write(a[1], hot, sizeof(hot)) == (ssize_t)sizeof(hot));
    assert(write(b[1], "STOP", 4) == 4);
    int ep = epoll_create1(EPOLL_CLOEXEC);
    assert(ep >= 0);
    struct epoll_event e = {.events = EPOLLIN, .data.u32 = 1};
    assert(epoll_ctl(ep, EPOLL_CTL_ADD, a[0], &e) == 0);
    e.data.u32 = 2;
    assert(epoll_ctl(ep, EPOLL_CTL_ADD, b[0], &e) == 0);
    struct epoll_event ready[2];
    assert(epoll_wait(ep, ready, 2, 100) == 2);
    unsigned processed = 0;
    int control = 0;
    for (unsigned i = 0; i < 2; i++) {
        if (ready[i].data.u32 == 1) {
            for (unsigned budget = 0; budget < 4; budget++) {
                char c;
                assert(read(a[0], &c, 1) == 1 && c == 'A');
                processed++;
            }
        } else {
            char c[4];
            assert(read(b[0], c, 4) == 4 && !memcmp(c, "STOP", 4));
            control = 1;
        }
    }
    assert(control && processed == 4);
    close(ep);
    for (unsigned i = 0; i < 2; i++) {
        close(a[i]);
        close(b[i]);
    }
    PASS("L3-LT-hot-source-control-budget");
}
static void stale(void) {
    int a[2];
    assert(pipe2(a, O_NONBLOCK | O_CLOEXEC) == 0);
    int ep = epoll_create1(EPOLL_CLOEXEC);
    struct epoll_event e = {.events = EPOLLIN, .data.u64 = 1};
    assert(ep >= 0 && epoll_ctl(ep, EPOLL_CTL_ADD, a[0], &e) == 0);
    assert(write(a[1], "A", 1) == 1);
    struct epoll_event old;
    assert(epoll_wait(ep, &old, 1, 100) == 1);
    int old_fd = a[0];
    assert(epoll_ctl(ep, EPOLL_CTL_DEL, a[0], NULL) == 0);
    close(a[0]);
    close(a[1]);
    assert(pipe2(a, O_NONBLOCK | O_CLOEXEC) == 0 && a[0] == old_fd);
    uint64_t generation = 2;
    assert(old.data.u64 != generation);
    e.data.u64 = generation;
    assert(epoll_ctl(ep, EPOLL_CTL_ADD, a[0], &e) == 0);
    assert(write(a[1], "B", 1) == 1);
    assert(epoll_wait(ep, &e, 1, 100) == 1 && e.data.u64 == generation);
    char c;
    assert(read(a[0], &c, 1) == 1 && c == 'B');
    close(a[0]);
    close(a[1]);
    close(ep);
    PASS("L3-ready-batch-generation-fd-reuse");
}
static void buffering(void) {
    char path[] = "/tmp/platform-stdio-XXXXXX";
    int fd = mkstemp(path);
    assert(fd >= 0);
    close(fd);
    for (unsigned flush = 0; flush < 2; flush++) {
        fflush(NULL);
        pid_t child = fork();
        assert(child >= 0);
        if (child == 0) {
            FILE *f = fopen(path, "w");
            if (!f)
                _exit(2);
            char buffer[512];
            if (setvbuf(f, buffer, _IOFBF, sizeof(buffer)))
                _exit(3);
            if (fwrite("BUFFER", 1, 6, f) != 6)
                _exit(4);
            if (flush)
                exit(0);
            _exit(0);
        }
        int status;
        assert(waitpid(child, &status, 0) == child && WEXITSTATUS(status) == 0);
        struct stat st;
        assert(stat(path, &st) == 0 && st.st_size == (flush ? 6 : 0));
    }
    unlink(path);
    PASS("L1-stdio-exit-vs-unflushed-exit");
}
static void permission(void) {
    char path[] = "/tmp/platform-permissions-XXXXXX";
    int fd = mkstemp(path);
    assert(fd >= 0 && fchmod(fd, 0600) == 0);
    close(fd);
    if (geteuid() != 0) {
        unlink(path);
        puts("{\"lab\":\"L1-permission-denied\",\"result\":\"SKIP\",\"reason\":\"requires isolated "
             "root child UID change\"}");
        return;
    }
    pid_t child = fork();
    assert(child >= 0);
    if (child == 0) {
        if (setuid(65534))
            _exit(2);
        fd = open(path, O_RDONLY);
        _exit(fd == -1 && errno == EACCES ? 0 : 3);
    }
    int status;
    assert(waitpid(child, &status, 0) == child && WEXITSTATUS(status) == 0);
    unlink(path);
    PASS("L1-permission-denied-child-UID");
}
int run_extra(void) {
    fairness();
    stale();
    buffering();
    permission();
    return 0;
}
