#include "abi_helper.h"
#include <assert.h>
#include <stdio.h>
int main(void) {
    assert(lab_sum(2, 3) == 5);
    puts("{\"lab\":\"L1-build-ELF\",\"result\":\"PASS\"}");
    return 0;
}
