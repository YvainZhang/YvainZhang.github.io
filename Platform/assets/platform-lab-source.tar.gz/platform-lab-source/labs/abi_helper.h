#ifndef LAB_ABI_HELPER_H
#define LAB_ABI_HELPER_H
int lab_sum(int, int);
#endif
