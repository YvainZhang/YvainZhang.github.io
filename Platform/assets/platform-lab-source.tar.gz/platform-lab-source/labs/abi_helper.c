#include "abi_helper.h"
int lab_sum(int a, int b) { return a + b; }
