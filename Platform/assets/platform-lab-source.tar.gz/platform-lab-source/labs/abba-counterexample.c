#define _GNU_SOURCE
/* Optional bounded counterexample: use timeout externally, never default test. */
#include <assert.h>
#include <pthread.h>
#include <stdio.h>
static pthread_mutex_t a = PTHREAD_MUTEX_INITIALIZER, b = PTHREAD_MUTEX_INITIALIZER;
static pthread_barrier_t acquired;
static void *worker(void *unused) {
    (void)unused;
    pthread_mutex_lock(&b);
    pthread_barrier_wait(&acquired);
    pthread_mutex_lock(&a);
    return NULL;
}
int main(void) {
    assert(pthread_barrier_init(&acquired, NULL, 2) == 0);
    pthread_t t;
    pthread_mutex_lock(&a);
    assert(pthread_create(&t, NULL, worker, NULL) == 0);
    pthread_barrier_wait(&acquired);
    puts("ABBA: both first locks acquired; waiting for opposite locks");
    fflush(stdout);
    pthread_mutex_lock(&b);
    pthread_join(t, NULL);
    return 0;
}
