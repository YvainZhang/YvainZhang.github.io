#define _GNU_SOURCE
#include <assert.h>
#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <poll.h>
#include <pthread.h>
#include <signal.h>
#include <stdatomic.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/epoll.h>
#include <sys/eventfd.h>
#include <sys/mman.h>
#include <sys/resource.h>
#include <sys/signalfd.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/timerfd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>
#define PASS(n) printf("{\"lab\":\"%s\",\"result\":\"PASS\"}\n", n)
static int fds(void) {
    DIR *d = opendir("/proc/self/fd");
    assert(d);
    int n = 0;
    while (readdir(d))
        n++;
    closedir(d);
    return n;
}
static void fd_lab(void) {
    int before = fds();
    char a[] = "/tmp/platform-fd-a-XXXXXX", b[] = "/tmp/platform-fd-b-XXXXXX";
    int one = mkstemp(a), temporary = mkstemp(b);
    assert(one >= 0 && temporary >= 0);
    close(temporary);
    assert(write(one, "ABCDEF", 6) == 6);
    assert(lseek(one, 0, SEEK_SET) == 0);
    int two = dup(one), three = open(a, O_RDONLY);
    assert(two >= 0 && three >= 0);
    char c;
    assert(read(one, &c, 1) == 1 && c == 'A');
    assert(read(two, &c, 1) == 1 && c == 'B');
    assert(read(three, &c, 1) == 1 && c == 'A');
    int old = one;
    assert(close(one) == 0);
    assert(read(two, &c, 1) == 1 && c == 'C');
    int newfd = open(b, O_RDWR);
    assert(newfd == old);
    assert(write(old, "NEW", 3) == 3);
    assert(lseek(newfd, 0, SEEK_SET) == 0);
    char text[3];
    assert(read(newfd, text, 3) == 3 && !memcmp(text, "NEW", 3));
    close(two);
    close(three);
    close(newfd);
    unlink(a);
    unlink(b);
    assert(fds() == before);
    PASS("L1-fd-dup-offset-reuse");
    errno = EACCES;
    int fd = open("/tmp/platform-lab-nonexistent-path-9e311/file", O_RDONLY);
    assert(fd == -1 && errno == ENOENT);
    errno = EACCES;
    assert(getpid() > 0);
    assert(errno == EACCES);
    assert(read(-1, &c, 1) == -1 && errno == EBADF);
    PASS("L1-errno-only-after-failure");
}
static void rollback(void) {
    int before = fds();
    for (unsigned fail = 0; fail < 4; fail++) {
        int fd = -1, p[2] = {-1, -1};
        void *memory = NULL;
        int error = 0;
        if (fail == 0) {
            error = EIO;
            goto cleanup;
        }
        fd = open("/dev/null", O_RDONLY);
        assert(fd >= 0);
        if (fail == 1) {
            error = ENOSPC;
            goto cleanup;
        }
        assert(pipe(p) == 0);
        if (fail == 2) {
            error = ENOMEM;
            goto cleanup;
        }
        memory = malloc(128);
        assert(memory);
    cleanup:
        free(memory);
        if (p[0] >= 0)
            close(p[0]);
        if (p[1] >= 0)
            close(p[1]);
        if (fd >= 0)
            close(fd);
        assert(fds() == before);
        assert(error == (fail == 0 ? EIO : fail == 1 ? ENOSPC : fail == 2 ? ENOMEM : 0));
    }
    PASS("L1-init-failure-rollback");
}
static void persistent_file(void) {
    char dir[] = "/tmp/platform-save-XXXXXX";
    assert(mkdtemp(dir));
    char temp[128], final[128];
    assert(snprintf(temp, sizeof(temp), "%s/config.tmp", dir) > 0);
    assert(snprintf(final, sizeof(final), "%s/config", dir) > 0);
    int fd = open(temp, O_CREAT | O_EXCL | O_WRONLY, 0600);
    assert(fd >= 0);
    assert(write(fd, "version=1\n", 10) == 10);
    assert(fsync(fd) == 0);
    assert(close(fd) == 0);
    assert(rename(temp, final) == 0);
    int d = open(dir, O_RDONLY | O_DIRECTORY);
    assert(d >= 0 && fsync(d) == 0);
    close(d);
    fd = open(final, O_RDONLY);
    char b[10];
    assert(read(fd, b, 10) == 10 && !memcmp(b, "version=1\n", 10));
    close(fd);
    unlink(final);
    rmdir(dir);
    PASS("L1-save-rename-file-directory-fsync");
}
static void ipc_lab(void) {
    int pipes[2];
    assert(pipe2(pipes, O_CLOEXEC) == 0);
    int local = 3;
    pid_t pid = fork();
    assert(pid >= 0);
    if (pid == 0) {
        close(pipes[0]);
        local = 7;
        if (write(pipes[1], &local, sizeof(local)) != (ssize_t)sizeof(local))
            _exit(1);
        _exit(0);
    }
    close(pipes[1]);
    int received;
    assert(read(pipes[0], &received, sizeof(received)) == (ssize_t)sizeof(received) &&
           received == 7 && local == 3);
    close(pipes[0]);
    int status;
    assert(waitpid(pid, &status, 0) == pid && WIFEXITED(status) && WEXITSTATUS(status) == 0);
    PASS("L2-fork-isolation-pipe-wait");
    pid = fork();
    assert(pid >= 0);
    if (pid == 0) {
        char *args[] = {"/no/platform-executable", NULL};
        execv(args[0], args);
        _exit(127);
    }
    assert(waitpid(pid, &status, 0) == pid && WEXITSTATUS(status) == 127);
    PASS("L2-exec-failure");
    assert(pipe2(pipes, O_CLOEXEC) == 0);
    assert((fcntl(pipes[0], F_GETFD) & FD_CLOEXEC) != 0);
    close(pipes[0]);
    close(pipes[1]);
    struct sigaction sa = {0}, old;
    sa.sa_handler = SIG_IGN;
    assert(sigaction(SIGPIPE, &sa, &old) == 0);
    assert(pipe(pipes) == 0);
    close(pipes[0]);
    assert(write(pipes[1], "X", 1) == -1 && errno == EPIPE);
    close(pipes[1]);
    sigaction(SIGPIPE, &old, NULL);
    PASS("L2-peer-exit-EPIPE");
}
struct blocking {
    int fd;
    pthread_mutex_t mutex;
    pthread_cond_t cv;
    int entered, done;
};
static void *blocking_reader(void *arg) {
    struct blocking *b = arg;
    pthread_mutex_lock(&b->mutex);
    b->entered = 1;
    pthread_cond_signal(&b->cv);
    pthread_mutex_unlock(&b->mutex);
    char c;
    assert(read(b->fd, &c, 1) == 1 && c == 'Q');
    pthread_mutex_lock(&b->mutex);
    b->done = 1;
    pthread_mutex_unlock(&b->mutex);
    return NULL;
}
static void blocking_lab(void) {
    int p[2];
    assert(pipe(p) == 0);
    struct blocking b = {
        .fd = p[0], .mutex = PTHREAD_MUTEX_INITIALIZER, .cv = PTHREAD_COND_INITIALIZER};
    pthread_t t;
    assert(pthread_create(&t, NULL, blocking_reader, &b) == 0);
    pthread_mutex_lock(&b.mutex);
    while (!b.entered)
        pthread_cond_wait(&b.cv, &b.mutex);
    assert(!b.done);
    pthread_mutex_unlock(&b.mutex);
    assert(write(p[1], "Q", 1) == 1);
    assert(pthread_join(t, NULL) == 0 && b.done);
    close(p[0]);
    close(p[1]);
    pthread_cond_destroy(&b.cv);
    pthread_mutex_destroy(&b.mutex);
    PASS("L2-L3-blocked-thread-other-thread-progress");
}
static void stream_lab(void) {
    int s[2];
    assert(socketpair(AF_UNIX, SOCK_STREAM, 0, s) == 0);
    uint8_t wire[] = {0, 3, 'A', 'B', 'C', 0, 2, 'D', 'E'};
    assert(write(s[0], wire, 1) == 1);
    assert(write(s[0], wire + 1, 8) == 8);
    shutdown(s[0], SHUT_WR);
    uint8_t all[16];
    size_t count = 0;
    ssize_t n;
    while ((n = read(s[1], all + count, 2)) > 0)
        count += (size_t)n;
    assert(n == 0 && count == 9);
    assert(all[1] == 3 && !memcmp(all + 2, "ABC", 3) && all[6] == 2 && !memcmp(all + 7, "DE", 2));
    close(s[0]);
    close(s[1]);
    assert(socketpair(AF_UNIX, SOCK_DGRAM, 0, s) == 0);
    assert(send(s[0], "ABCDE", 5, 0) == 5);
    char b[2];
    assert(recv(s[1], b, 2, 0) == 2);
    assert(fcntl(s[1], F_SETFL, O_NONBLOCK) == 0);
    assert(recv(s[1], b, 2, 0) == -1 && errno == EAGAIN);
    close(s[0]);
    close(s[1]);
    PASS("L1-L6-stream-vs-datagram-boundary");
}
static void epoll_lab(void) {
    int p[2];
    assert(pipe2(p, O_NONBLOCK | O_CLOEXEC) == 0);
    int ep = epoll_create1(EPOLL_CLOEXEC);
    assert(ep >= 0);
    struct epoll_event ev = {.events = EPOLLIN | EPOLLET, .data.u64 = 0x100000001};
    assert(epoll_ctl(ep, EPOLL_CTL_ADD, p[0], &ev) == 0);
    assert(write(p[1], "ABC", 3) == 3);
    assert(epoll_wait(ep, &ev, 1, 100) == 1);
    char c;
    assert(read(p[0], &c, 1) == 1 && c == 'A');
    assert(epoll_wait(ep, &ev, 1, 0) == 0);
    char b[8];
    assert(read(p[0], b, sizeof(b)) == 2 && !memcmp(b, "BC", 2));
    assert(read(p[0], b, sizeof(b)) == -1 && errno == EAGAIN);
    PASS("L3-ET-partial-read-counterexample-drain");
    ev.events = EPOLLIN;
    assert(epoll_ctl(ep, EPOLL_CTL_MOD, p[0], &ev) == 0);
    assert(write(p[1], "DEF", 3) == 3);
    assert(epoll_wait(ep, &ev, 1, 100) == 1);
    assert(read(p[0], &c, 1) == 1 && c == 'D');
    assert(epoll_wait(ep, &ev, 1, 0) == 1);
    assert(read(p[0], b, sizeof(b)) == 2);
    close(p[1]);
    assert(epoll_wait(ep, &ev, 1, 100) == 1 && (ev.events & EPOLLHUP));
    assert(read(p[0], b, sizeof(b)) == 0);
    close(p[0]);
    close(ep);
    PASS("L3-LT-budget-HUP-EOF");
    int event = eventfd(0, EFD_NONBLOCK | EFD_CLOEXEC);
    assert(event >= 0);
    uint64_t one = 1, v;
    assert(write(event, &one, 8) == 8 && write(event, &one, 8) == 8);
    assert(read(event, &v, 8) == 8 && v == 2);
    assert(read(event, &v, 8) == -1 && errno == EAGAIN);
    close(event);
    PASS("L3-eventfd-notification-coalesces");
    int timer = timerfd_create(CLOCK_MONOTONIC, TFD_CLOEXEC);
    assert(timer >= 0);
    struct itimerspec due = {.it_value = {0, 1000000}};
    assert(timerfd_settime(timer, 0, &due, NULL) == 0);
    assert(read(timer, &v, 8) == 8 && v >= 1);
    close(timer);
    PASS("L3-timerfd-monotonic");
    sigset_t mask, old;
    sigemptyset(&mask);
    sigaddset(&mask, SIGUSR1);
    assert(pthread_sigmask(SIG_BLOCK, &mask, &old) == 0);
    int signal_fd = signalfd(-1, &mask, SFD_CLOEXEC);
    assert(signal_fd >= 0);
    assert(kill(getpid(), SIGUSR1) == 0);
    struct signalfd_siginfo info;
    assert(read(signal_fd, &info, sizeof(info)) == (ssize_t)sizeof(info) &&
           info.ssi_signo == SIGUSR1);
    close(signal_fd);
    assert(pthread_sigmask(SIG_SETMASK, &old, NULL) == 0);
    PASS("L3-signalfd-mask");
}
static void partial_write_lab(void) {
    int s[2];
    assert(socketpair(AF_UNIX, SOCK_STREAM | SOCK_NONBLOCK, 0, s) == 0);
    int size = 1024;
    setsockopt(s[0], SOL_SOCKET, SO_SNDBUF, &size, sizeof(size));
    uint8_t source[65536], received[65536];
    for (size_t i = 0; i < sizeof(source); i++)
        source[i] = (uint8_t)i;
    size_t sent = 0, readn = 0;
    int saw_again = 0;
    while (sent < sizeof(source)) {
        ssize_t n = send(s[0], source + sent, sizeof(source) - sent, MSG_NOSIGNAL);
        if (n > 0)
            sent += (size_t)n;
        else {
            assert(errno == EAGAIN);
            saw_again = 1;
            break;
        }
    }
    assert(saw_again);
    while (readn < sizeof(source)) {
        ssize_t n = recv(s[1], received + readn, sizeof(received) - readn, 0);
        if (n > 0)
            readn += (size_t)n;
        else
            assert(errno == EAGAIN);
        if (sent < sizeof(source)) {
            n = send(s[0], source + sent, sizeof(source) - sent, MSG_NOSIGNAL);
            if (n > 0)
                sent += (size_t)n;
            else
                assert(errno == EAGAIN);
        }
    }
    assert(sent == sizeof(source) && !memcmp(source, received, sizeof(source)));
    close(s[0]);
    close(s[1]);
    PASS("L3-partial-write-EAGAIN-offset");
}
#define QCAP 3
struct queue {
    pthread_mutex_t mutex;
    pthread_cond_t ready, space;
    unsigned values[QCAP];
    size_t head, count;
    int stopped;
    uint64_t push, pop;
};
static void *producer(void *ctx) {
    struct queue *q = ctx;
    for (unsigned i = 0; i < 1000; i++) {
        pthread_mutex_lock(&q->mutex);
        while (q->count == QCAP && !q->stopped)
            pthread_cond_wait(&q->space, &q->mutex);
        if (q->stopped) {
            pthread_mutex_unlock(&q->mutex);
            break;
        }
        q->values[(q->head + q->count) % QCAP] = i;
        q->count++;
        q->push++;
        pthread_cond_signal(&q->ready);
        pthread_mutex_unlock(&q->mutex);
    }
    return NULL;
}
static void *consumer(void *ctx) {
    struct queue *q = ctx;
    unsigned expected = 0;
    for (;;) {
        pthread_mutex_lock(&q->mutex);
        while (!q->count && !q->stopped)
            pthread_cond_wait(&q->ready, &q->mutex);
        if (!q->count && q->stopped) {
            pthread_mutex_unlock(&q->mutex);
            break;
        }
        assert(q->values[q->head] == expected++);
        q->head = (q->head + 1) % QCAP;
        q->count--;
        q->pop++;
        pthread_cond_signal(&q->space);
        pthread_mutex_unlock(&q->mutex);
    }
    return NULL;
}
static void queue_lab(void) {
    struct queue q = {.mutex = PTHREAD_MUTEX_INITIALIZER,
                      .ready = PTHREAD_COND_INITIALIZER,
                      .space = PTHREAD_COND_INITIALIZER};
    pthread_t a, b; /* notify before wait: predicate, not notification, stores work */
    pthread_cond_broadcast(&q.ready);
    assert(pthread_create(&b, NULL, consumer, &q) == 0);
    assert(pthread_create(&a, NULL, producer, &q) == 0);
    pthread_join(a, NULL);
    pthread_mutex_lock(&q.mutex);
    q.stopped = 1;
    pthread_cond_broadcast(&q.ready);
    pthread_cond_broadcast(&q.space);
    pthread_mutex_unlock(&q.mutex);
    pthread_join(b, NULL);
    assert(q.push == 1000 && q.pop == 1000 && !q.count);
    pthread_cond_destroy(&q.ready);
    pthread_cond_destroy(&q.space);
    pthread_mutex_destroy(&q.mutex);
    PASS("L4-bounded-queue-wrap-predicate-stop-conservation");
}
struct publication {
    atomic_int ready;
    int value;
};
static void *publish_value(void *arg) {
    struct publication *p = arg;
    p->value = 42;
    atomic_store_explicit(&p->ready, 1, memory_order_release);
    return NULL;
}
static void atomic_lab(void) {
    struct publication p;
    atomic_init(&p.ready, 0);
    p.value = 0;
    pthread_t t;
    assert(pthread_create(&t, NULL, publish_value, &p) == 0);
    while (!atomic_load_explicit(&p.ready, memory_order_acquire))
        sched_yield();
    assert(p.value == 42);
    pthread_join(t, NULL);
    PASS("L4-acquire-release-publication");
}
static void memory_lab(void) {
    size_t page = (size_t)sysconf(_SC_PAGESIZE), bytes = page * 1024;
    struct rusage before, after;
    getrusage(RUSAGE_SELF, &before);
    uint8_t *p = mmap(NULL, bytes, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    assert(p != MAP_FAILED);
    for (size_t i = 0; i < bytes; i += page)
        p[i] = 1;
    getrusage(RUSAGE_SELF, &after);
    assert(after.ru_minflt >= before.ru_minflt);
    printf("{\"lab\":\"L5-page-touch\",\"minor_fault_delta\":%ld,\"pages\":1024,\"result\":"
           "\"PASS\"}\n",
           after.ru_minflt - before.ru_minflt);
    pid_t pid = fork();
    assert(pid >= 0);
    if (pid == 0) {
        p[0] = 9;
        _exit(0);
    }
    int status;
    assert(waitpid(pid, &status, 0) == pid && WEXITSTATUS(status) == 0 && p[0] == 1);
    munmap(p, bytes);
    PASS("L5-private-mapping-COW");
    int *shared = mmap(NULL, page, PROT_READ | PROT_WRITE, MAP_SHARED | MAP_ANONYMOUS, -1, 0);
    assert(shared != MAP_FAILED);
    *shared = 1;
    pid = fork();
    assert(pid >= 0);
    if (pid == 0) {
        *shared = 8;
        _exit(0);
    }
    assert(waitpid(pid, &status, 0) == pid && *shared == 8);
    munmap(shared, page);
    PASS("L2-L5-shared-mapping-wait-synchronization");
}
int run_extra(void);
static void extra_lab(void) {
    assert(run_extra() == 0);
}
int main(int argc, char **argv) {
    const struct {
        const char *name;
        void (*run)(void);
    } experiments[] = {{"fd", fd_lab},
                       {"rollback", rollback},
                       {"save", persistent_file},
                       {"ipc", ipc_lab},
                       {"blocking", blocking_lab},
                       {"stream", stream_lab},
                       {"epoll", epoll_lab},
                       {"partial-write", partial_write_lab},
                       {"queue", queue_lab},
                       {"atomic", atomic_lab},
                       {"memory", memory_lab},
                       {"extra", extra_lab}};
    if (argc > 2) {
        fprintf(stderr, "usage: %s [all|--list|EXPERIMENT]\n", argv[0]);
        return 2;
    }
    const char *selection = argc == 2 ? argv[1] : "all";
    if (!strcmp(selection, "--list")) {
        for (size_t i = 0; i < sizeof(experiments) / sizeof(experiments[0]); i++)
            puts(experiments[i].name);
        return 0;
    }
    int baseline = fds();
    int found = 0;
    for (size_t i = 0; i < sizeof(experiments) / sizeof(experiments[0]); i++) {
        if (!strcmp(selection, "all") || !strcmp(selection, experiments[i].name)) {
            experiments[i].run();
            found = 1;
        }
    }
    if (!found) {
        fprintf(stderr, "unknown experiment: %s (use --list)\n", selection);
        return 2;
    }
    assert(fds() == baseline);
    PASS("all-fd-resources-return-to-baseline");
    return 0;
}
