#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <linux/if_tun.h>
#include <net/if.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/epoll.h>
#include <sys/ioctl.h>
#include <time.h>
#include <unistd.h>
#define ITEMS 32u
#define BYTE_BUDGET (1024u * 1024u)
#define FRAME_MAX 65536u
struct frame {
    size_t length;
    uint64_t due;
    unsigned char bytes[FRAME_MAX];
};
struct direction {
    struct frame frames[ITEMS];
    size_t head, count, bytes;
    uint64_t received, forwarded, dropped, policy_sequence;
    unsigned delay, drop_every;
};
static volatile sig_atomic_t stopping, block_requested;
static void stop(int sig) {
    (void)sig;
    stopping = 1;
}
static void block(int sig) {
    (void)sig;
    block_requested = 1;
}
static void resume(int sig) {
    (void)sig;
    block_requested = 0;
}
static uint64_t now_ms(void) {
    struct timespec t;
    clock_gettime(CLOCK_MONOTONIC, &t);
    return (uint64_t)t.tv_sec * 1000 + (uint64_t)t.tv_nsec / 1000000;
}
static int tap_open(const char *name) {
    struct ifreq r = {0};
    if (strlen(name) >= IFNAMSIZ) {
        errno = EINVAL;
        return -1;
    }
    int fd = open("/dev/net/tun", O_RDWR | O_NONBLOCK | O_CLOEXEC);
    if (fd < 0)
        return -1;
    r.ifr_flags = IFF_TAP | IFF_NO_PI;
    strcpy(r.ifr_name, name);
    if (ioctl(fd, TUNSETIFF, &r) < 0) {
        int saved = errno;
        close(fd);
        errno = saved;
        return -1;
    }
    return fd;
}
static int number(const char *s, unsigned max, unsigned *out) {
    char *end;
    errno = 0;
    unsigned long n = strtoul(s, &end, 10);
    if (errno || !s[0] || *end || s[0] == '-' || n > max)
        return -1;
    *out = (unsigned)n;
    return 0;
}
static void discard(struct direction *d) {
    d->dropped += d->count;
    d->head = d->count = d->bytes = 0;
}
static int flush(struct direction *d, int fd, uint64_t now) {
    for (unsigned n = 0; n < ITEMS && d->count; n++) {
        struct frame *f = &d->frames[d->head];
        if (f->due > now)
            break;
        ssize_t wrote = write(fd, f->bytes, f->length);
        if (wrote < 0 && (errno == EAGAIN || errno == EINTR))
            break;
        if (wrote != (ssize_t)f->length) {
            if (wrote >= 0)
                errno = EIO;
            return -1;
        }
        d->forwarded++;
        d->bytes -= f->length;
        d->head = (d->head + 1) % ITEMS;
        d->count--;
    }
    return 0;
}
int main(int argc, char **argv) {
    if (argc < 3 || strcmp(argv[1], argv[2]) == 0) {
        fprintf(stderr,
                "usage: %s TAP_A TAP_B [--delay-ms N] [--drop-every N] [--delay-a-ms N] "
                "[--delay-b-ms N] [--drop-a-every N] [--drop-b-every N]\n",
                argv[0]);
        return 1;
    }
    struct direction *dirs = calloc(2, sizeof(*dirs));
    if (!dirs)
        return 1;
    unsigned policy_ethertype = 0;
    for (int arg = 3; arg < argc; arg += 2) {
        if (arg + 1 == argc)
            goto usage;
        unsigned n;
        const char *key = argv[arg];
        int delay = strstr(key, "delay") != NULL;
        if (number(argv[arg + 1], delay ? 10000 : 1000000, &n))
            goto usage;
        if (!strcmp(key, "--policy-ethertype")) {
            if (n > 65535)
                goto usage;
            policy_ethertype = n;
        } else if (!strcmp(key, "--delay-ms")) {
            dirs[0].delay = dirs[1].delay = n;
        } else if (!strcmp(key, "--drop-every")) {
            dirs[0].drop_every = dirs[1].drop_every = n;
        } else if (!strcmp(key, "--delay-a-ms"))
            dirs[0].delay = n;
        else if (!strcmp(key, "--delay-b-ms"))
            dirs[1].delay = n;
        else if (!strcmp(key, "--drop-a-every"))
            dirs[0].drop_every = n;
        else if (!strcmp(key, "--drop-b-every"))
            dirs[1].drop_every = n;
        else
            goto usage;
    }
    int fd[2] = {-1, -1}, ep = -1, status = 1;
    struct sigaction action = {0};
    sigemptyset(&action.sa_mask);
    action.sa_handler = stop;
    if (sigaction(SIGINT, &action, NULL) || sigaction(SIGTERM, &action, NULL))
        goto error;
    action.sa_handler = block;
    if (sigaction(SIGUSR1, &action, NULL))
        goto error;
    action.sa_handler = resume;
    if (sigaction(SIGUSR2, &action, NULL))
        goto error;
    for (unsigned i = 0; i < 2; i++) {
        fd[i] = tap_open(argv[i + 1]);
        if (fd[i] < 0)
            goto error;
    }
    ep = epoll_create1(EPOLL_CLOEXEC);
    if (ep < 0)
        goto error;
    for (unsigned i = 0; i < 2; i++) {
        struct epoll_event e = {.events = EPOLLIN, .data.u32 = i};
        if (epoll_ctl(ep, EPOLL_CTL_ADD, fd[i], &e) < 0)
            goto error;
    }
    puts("ready");
    fflush(stdout);
    int blocked = 0;
    unsigned traced = 0;
    while (!stopping) {
        if (blocked != block_requested) {
            blocked = block_requested;
            printf("mode=%s\n", blocked ? "blocked" : "forwarding");
            fflush(stdout);
        }
        uint64_t now = now_ms();
        int timeout = 200;
        for (unsigned i = 0; i < 2; i++) {
            if (block_requested)
                discard(&dirs[i]);
            else if (flush(&dirs[i], fd[1 - i], now))
                goto error;
            struct direction *out = &dirs[1 - i];
            unsigned events = EPOLLIN;
            if (out->count && out->frames[out->head].due <= now)
                events |= EPOLLOUT;
            struct epoll_event e = {.events = events, .data.u32 = i};
            if (epoll_ctl(ep, EPOLL_CTL_MOD, fd[i], &e) < 0)
                goto error;
            if (out->count && out->frames[out->head].due > now) {
                uint64_t left = out->frames[out->head].due - now;
                if (left < (uint64_t)timeout)
                    timeout = (int)left;
            }
        }
        struct epoll_event events[2];
        int count = epoll_wait(ep, events, 2, timeout);
        if (count < 0) {
            if (errno == EINTR)
                continue;
            goto error;
        }
        for (int n = 0; n < count && !stopping; n++) {
            unsigned i = events[n].data.u32;
            struct direction *d = &dirs[i];
            if (events[n].events & (EPOLLERR | EPOLLHUP)) {
                errno = EIO;
                goto error;
            }
            if (!(events[n].events & EPOLLIN))
                continue;
            for (unsigned budget = 0; budget < 64 && !stopping; budget++) {
                unsigned char frame[FRAME_MAX];
                ssize_t len = read(fd[i], frame, sizeof(frame));
                if (len < 0) {
                    if (errno == EAGAIN)
                        break;
                    if (errno == EINTR)
                        continue;
                    goto error;
                }
                if (!len) {
                    errno = EIO;
                    goto error;
                }
                d->received++;
                unsigned ether = len >= 14 ? ((unsigned)frame[12] << 8) | frame[13] : 0;
                int matches = !policy_ethertype || ether == policy_ethertype;
                if (matches)
                    d->policy_sequence++;
                if (len >= 14 && traced < 16) {
                    printf("frame %s->%s type=0x%04x bytes=%zd seq=%llu\n", i ? "B" : "A",
                           i ? "A" : "B", ((unsigned)frame[12] << 8) | frame[13], len,
                           (unsigned long long)d->received);
                    fflush(stdout);
                    traced++;
                }
                if (block_requested ||
                    (d->drop_every && matches && d->policy_sequence % d->drop_every == 0) ||
                    d->count == ITEMS || (size_t)len > BYTE_BUDGET - d->bytes) {
                    d->dropped++;
                    continue;
                }
                struct frame *f = &d->frames[(d->head + d->count) % ITEMS];
                f->length = (size_t)len;
                f->due = now_ms() + d->delay;
                memcpy(f->bytes, frame, (size_t)len);
                d->bytes += (size_t)len;
                d->count++;
            }
        }
    }
    status = 0;
    goto cleanup;
error:
    perror("link-lab");
cleanup:
    for (unsigned i = 0; i < 2; i++) {
        discard(&dirs[i]);
        printf("%s forwarded=%llu dropped=%llu received=%llu queued=%zu\n", i ? "B->A" : "A->B",
               (unsigned long long)dirs[i].forwarded, (unsigned long long)dirs[i].dropped,
               (unsigned long long)dirs[i].received, dirs[i].count);
        if (dirs[i].received != dirs[i].forwarded + dirs[i].dropped)
            status = 1;
    }
    if (ep >= 0)
        close(ep);
    for (unsigned i = 0; i < 2; i++)
        if (fd[i] >= 0)
            close(fd[i]);
    free(dirs);
    return status;
usage:
    fprintf(stderr, "invalid option/value (delay 0..10000 ms, drop period 0..1000000)\n");
    free(dirs);
    return 2;
}
