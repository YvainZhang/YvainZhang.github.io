#!/bin/sh
# Build artifacts in the dedicated project tool container. Does not load modules.
set -eu
cd "$(dirname "$0")/.."
test "$(uname -m)" = aarch64 || { echo "ARM64 Alpine userspace required" >&2; exit 2; }
test -f /lib/ld-musl-aarch64.so.1 || { echo "ARM64 musl loader missing" >&2; exit 2; }
version=$(basename /lib/modules/*-virt)
kdir=/lib/modules/$version/build
make -C kernel-labs/archlab KDIR="$kdir"
mkdir -p build/vm/root/bin build/vm/root/dev build/vm/root/proc build/vm/root/sys build/vm/root/lib
cp /bin/busybox build/vm/root/bin/
cp /lib/ld-musl-aarch64.so.1 build/vm/root/lib/
cc -std=c11 -Wall -Wextra -Werror -static kernel-labs/archlab/uapi_test.c -o build/vm/root/uapi-test
cp kernel-labs/archlab/archlab.ko build/vm/root/
cp /boot/vmlinuz-virt build/vm/Image
cp "$kdir/.config" build/vm/kernel.config
printf '%s\n' "$version" > build/vm/kernel.version
cat > build/vm/root/init <<'INIT'
#!/bin/busybox sh
export PATH=/bin
/bin/busybox --install -s /bin
mount -t proc proc /proc
mount -t sysfs sysfs /sys
mount -t devtmpfs devtmpfs /dev
set -eu
insmod /archlab.ko
/uapi-test
rmmod archlab
for fail in 1 2; do
 insmod /archlab.ko fail_probe=$fail
 test ! -e /dev/archlab0
 test ! -e /dev/archlab1
 rmmod archlab
done
for round in 1 2 3; do
 insmod /archlab.ko
 /uapi-test
 rmmod archlab
done
if dmesg | grep -E 'BUG:|WARNING:|Oops:|KASAN:|possible circular locking'; then
 echo 'KERNEL_VM_FAIL'; poweroff -f; exit 1
fi
echo 'KERNEL_VM_PASS'
poweroff -f
INIT
chmod +x build/vm/root/init
(cd build/vm/root && find . | cpio -o -H newc) | gzip > build/vm/initramfs.cpio.gz
sha256sum build/vm/Image build/vm/initramfs.cpio.gz build/vm/kernel.config > build/vm/artifacts.sha256
