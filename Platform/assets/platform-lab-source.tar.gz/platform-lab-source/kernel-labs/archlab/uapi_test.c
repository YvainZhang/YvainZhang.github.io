#define _GNU_SOURCE
#include "archlab_uapi.h"
#include <assert.h>
#include <errno.h>
#include <fcntl.h>
#include <poll.h>
#include <stdio.h>
#include <string.h>
#include <sys/ioctl.h>
#include <unistd.h>
static int open_device(unsigned n) {
    char p[64];
    snprintf(p, sizeof(p), "/dev/archlab%u", n);
    int fd = open(p, O_RDONLY | O_NONBLOCK);
    assert(fd >= 0);
    return fd;
}
static void unbind(void) {
    int fd = open("/sys/bus/platform/drivers/archlab/unbind", O_WRONLY);
    assert(fd >= 0);
    assert(write(fd, "archlab.0", 9) == 9);
    close(fd);
}
static void record(int fd) {
    struct pollfd p = {.fd = fd, .events = POLLIN};
    assert(poll(&p, 1, 1000) > 0);
    struct archlab_record r;
    assert(read(fd, &r, sizeof(r)) == (ssize_t)sizeof(r));
    assert(r.version == 1 && r.length == 16);
    for (unsigned i = 0; i < 16; i++)
        assert(r.payload[i] == (unsigned char)r.sequence);
}
int main(void) {
    int a = open_device(0), b = open_device(1);
    record(a);
    record(b);
    struct archlab_stats st;
    assert(ioctl(a, ARCHLAB_GET_STATS, &st) == 0 &&
           st.generated == st.delivered + st.dropped + st.queued);
    assert(ioctl(a, 0x12345, &st) == -1 && errno == ENOTTY);
    assert(ioctl(a, ARCHLAB_GET_STATS, (void *)1) == -1 && errno == EFAULT);
    char shortbuf[1];
    assert(read(a, shortbuf, 1) == -1 && errno == EMSGSIZE);
    /* Hold open session across unbind: drain records then EOF, other device remains active. */
    unbind();
    struct archlab_record r;
    ssize_t n;
    unsigned reads = 0;
    while ((n = read(a, &r, sizeof(r))) > 0)
        assert(++reads <= 16);
    assert(n == 0);
    struct pollfd p = {.fd = a, .events = POLLIN};
    assert(poll(&p, 1, 0) == 1 && (p.revents & POLLHUP));
    record(b);
    close(a);
    close(b);
    puts("{\"kernel\":\"uapi-unbind-multi-instance\",\"result\":\"PASS\"}");
    return 0;
}
