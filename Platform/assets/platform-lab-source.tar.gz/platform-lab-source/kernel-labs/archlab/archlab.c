// SPDX-License-Identifier: GPL-2.0-only
#include "archlab_uapi.h"
#include <linux/fs.h>
#include <linux/kref.h>
#include <linux/miscdevice.h>
#include <linux/module.h>
#include <linux/mutex.h>
#include <linux/platform_device.h>
#include <linux/poll.h>
#include <linux/slab.h>
#include <linux/uaccess.h>
#include <linux/workqueue.h>
#define CAPACITY 16
struct archlab {
    struct miscdevice misc;
    struct mutex lock;
    struct kref ref;
    wait_queue_head_t wait;
    struct delayed_work work;
    bool dead;
    struct archlab_record records[CAPACITY];
    unsigned head, count;
    u64 generated, delivered, dropped;
    unsigned instance;
    char name[24];
};
static int fail_probe;
module_param(fail_probe, int, 0444);
MODULE_PARM_DESC(fail_probe,
                 "Inject probe rollback: 1 after allocation, 2 after misc registration");
static struct platform_device *devices[2];
static void release_instance(struct kref *ref) {
    struct archlab *d = container_of(ref, struct archlab, ref);
    pr_info("archlab release instance=%u\n", d->instance);
    kfree(d);
}
static void generate(struct work_struct *work) {
    struct archlab *d = container_of(to_delayed_work(work), struct archlab, work);
    mutex_lock(&d->lock);
    if (d->dead) {
        mutex_unlock(&d->lock);
        return;
    }
    d->generated++;
    if (d->count == CAPACITY)
        d->dropped++;
    else {
        struct archlab_record *r = &d->records[(d->head + d->count) % CAPACITY];
        memset(r, 0, sizeof(*r));
        r->version = ARCHLAB_VERSION;
        r->length = sizeof(r->payload);
        r->sequence = d->generated;
        memset(r->payload, (u8)r->sequence, sizeof(r->payload));
        WRITE_ONCE(d->count, d->count + 1);
    }
    /* Same lock protects stopping and the permission to requeue. */
    schedule_delayed_work(&d->work, msecs_to_jiffies(10));
    mutex_unlock(&d->lock);
    wake_up_interruptible(&d->wait);
}
static int open_session(struct inode *inode, struct file *file) {
    struct miscdevice *misc = file->private_data;
    struct archlab *d = container_of(misc, struct archlab, misc);
    (void)inode;
    mutex_lock(&d->lock);
    if (d->dead) {
        mutex_unlock(&d->lock);
        return -ENODEV;
    }
    kref_get(&d->ref);
    file->private_data = d;
    mutex_unlock(&d->lock);
    return nonseekable_open(inode, file);
}
static int close_session(struct inode *inode, struct file *file) {
    struct archlab *d = file->private_data;
    (void)inode;
    kref_put(&d->ref, release_instance);
    return 0;
}
static ssize_t read_record(struct file *file, char __user *buffer, size_t count, loff_t *pos) {
    struct archlab *d = file->private_data;
    int ret;
    (void)pos;
    if (count < sizeof(struct archlab_record))
        return -EMSGSIZE;
    for (;;) {
        if (mutex_lock_interruptible(&d->lock))
            return -ERESTARTSYS;
        if (d->count)
            break;
        if (d->dead) {
            mutex_unlock(&d->lock);
            return 0;
        }
        mutex_unlock(&d->lock);
        if (file->f_flags & O_NONBLOCK)
            return -EAGAIN;
        ret = wait_event_interruptible(d->wait, READ_ONCE(d->count) || READ_ONCE(d->dead));
        if (ret)
            return ret;
    }
    if (copy_to_user(buffer, &d->records[d->head], sizeof(struct archlab_record))) {
        mutex_unlock(&d->lock);
        return -EFAULT;
    }
    d->head = (d->head + 1) % CAPACITY;
    WRITE_ONCE(d->count, d->count - 1);
    d->delivered++;
    mutex_unlock(&d->lock);
    return sizeof(struct archlab_record);
}
static __poll_t poll_records(struct file *file, poll_table *wait) {
    struct archlab *d = file->private_data;
    __poll_t mask = 0;
    poll_wait(file, &d->wait, wait);
    mutex_lock(&d->lock);
    if (d->count)
        mask |= EPOLLIN | EPOLLRDNORM;
    if (d->dead)
        mask |= EPOLLHUP;
    mutex_unlock(&d->lock);
    return mask;
}
static long ioctl_stats(struct file *file, unsigned int cmd, unsigned long arg) {
    struct archlab *d = file->private_data;
    struct archlab_stats s;
    if (cmd != ARCHLAB_GET_STATS)
        return -ENOTTY;
    memset(&s, 0, sizeof(s));
    mutex_lock(&d->lock);
    s.version = ARCHLAB_VERSION;
    s.instance = d->instance;
    s.generated = d->generated;
    s.delivered = d->delivered;
    s.dropped = d->dropped;
    s.queued = d->count;
    mutex_unlock(&d->lock);
    return copy_to_user((void __user *)arg, &s, sizeof(s)) ? -EFAULT : 0;
}
static const struct file_operations ops = {.owner = THIS_MODULE,
                                           .open = open_session,
                                           .release = close_session,
                                           .read = read_record,
                                           .poll = poll_records,
                                           .unlocked_ioctl = ioctl_stats,
                                           .llseek = NULL};
static int probe(struct platform_device *pdev) {
    struct archlab *d = kzalloc(sizeof(*d), GFP_KERNEL);
    int ret;
    if (!d)
        return -ENOMEM;
    mutex_init(&d->lock);
    kref_init(&d->ref);
    init_waitqueue_head(&d->wait);
    INIT_DELAYED_WORK(&d->work, generate);
    d->instance = pdev->id;
    snprintf(d->name, sizeof(d->name), "archlab%d", pdev->id);
    d->misc.minor = MISC_DYNAMIC_MINOR;
    d->misc.name = d->name;
    d->misc.fops = &ops;
    d->misc.parent = &pdev->dev;
    if (fail_probe == 1) {
        ret = -EIO;
        goto put;
    }
    ret = misc_register(&d->misc);
    if (ret)
        goto put;
    if (fail_probe == 2) {
        ret = -EIO;
        misc_deregister(&d->misc);
        goto put;
    }
    platform_set_drvdata(pdev, d);
    schedule_delayed_work(&d->work, msecs_to_jiffies(10));
    pr_info("archlab ready instance=%u\n", d->instance);
    return 0;
put:
    kref_put(&d->ref, release_instance);
    return ret;
}
static void remove_device(struct platform_device *pdev) {
    struct archlab *d = platform_get_drvdata(pdev);
    mutex_lock(&d->lock);
    WRITE_ONCE(d->dead, true);
    mutex_unlock(&d->lock);
    misc_deregister(&d->misc);
    cancel_delayed_work_sync(&d->work);
    wake_up_interruptible(&d->wait);
    platform_set_drvdata(pdev, NULL);
    kref_put(&d->ref, release_instance);
}
static struct platform_driver driver = {
    .probe = probe, .remove = remove_device, .driver = {.name = "archlab"}};
static int __init init_lab(void) {
    int ret = platform_driver_register(&driver);
    if (ret)
        return ret;
    for (unsigned i = 0; i < 2; i++) {
        devices[i] = platform_device_register_simple("archlab", i, NULL, 0);
        if (IS_ERR(devices[i])) {
            ret = PTR_ERR(devices[i]);
            devices[i] = NULL;
            while (i)
                platform_device_unregister(devices[--i]);
            platform_driver_unregister(&driver);
            return ret;
        }
    }
    return 0;
}
static void __exit exit_lab(void) {
    for (unsigned i = 0; i < 2; i++)
        platform_device_unregister(devices[i]);
    platform_driver_unregister(&driver);
}
module_init(init_lab);
module_exit(exit_lab);
MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("Bounded platform misc-device lifetime tutorial");
