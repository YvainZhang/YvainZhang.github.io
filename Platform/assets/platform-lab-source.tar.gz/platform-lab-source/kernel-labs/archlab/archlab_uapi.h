#ifndef ARCHLAB_UAPI_H
#define ARCHLAB_UAPI_H
#include <linux/ioctl.h>
#include <linux/types.h>
#define ARCHLAB_VERSION 1u
struct archlab_record {
    __u32 version, length;
    __aligned_u64 sequence;
    __u8 payload[16];
};
struct archlab_stats {
    __u32 version, instance;
    __aligned_u64 generated, delivered, dropped, queued;
};
#define ARCHLAB_GET_STATS _IOR('A', 1, struct archlab_stats)
#endif
