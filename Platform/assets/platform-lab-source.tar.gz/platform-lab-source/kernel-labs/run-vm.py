#!/usr/bin/env python3
"""Dedicated QEMU only: never insmod into the container/host kernel."""
import argparse
import pathlib
import subprocess
import sys
parser = argparse.ArgumentParser()
parser.add_argument('--qemu', default='qemu-system-aarch64')
parser.add_argument('--log', default='build/vm/serial.log')
args = parser.parse_args()
root = pathlib.Path(__file__).resolve().parents[1]
command = [args.qemu, '-machine', 'virt', '-cpu', 'cortex-a72', '-accel', 'tcg',
           '-m', '512', '-smp', '2', '-nographic', '-no-reboot', '-nic', 'none',
           '-kernel', str(root/'build/vm/Image'),
           '-initrd', str(root/'build/vm/initramfs.cpio.gz'),
           '-append', 'console=ttyAMA0 rdinit=/init panic=-1']
try:
    result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                            timeout=90, check=False)
    output = result.stdout
except subprocess.TimeoutExpired as exc:
    output = exc.stdout or b''
    result = None
path = root/args.log
path.parent.mkdir(parents=True, exist_ok=True)
path.write_bytes(output)
passed = result is not None and result.returncode == 0 and b'KERNEL_VM_PASS' in output
print({'kernel_vm': 'PASS' if passed else 'FAIL', 'serial_log': str(path)})
if not passed:
    print(output[-6000:].decode(errors='replace'))
sys.exit(0 if passed else 1)
