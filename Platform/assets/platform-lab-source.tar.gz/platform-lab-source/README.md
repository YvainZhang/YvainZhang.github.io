# Platform laboratory source

Linux mechanisms and a bounded asynchronous C SDK: descriptor lifetime, events,
queues, request completion, stop/recovery, TAP networking, and a FreeRTOS runtime
comparison. The public tutorial is at https://xidianedu.cc/tech/platform/.

## Environments and isolation

The default user experiments run in a disposable Linux container. GCC, make,
Python 3, binutils and Linux headers are required. Run from this archive's root.
The Alpine tool image is pinned by digest; build it on the host:

```sh
docker build -f scripts/deps/Dockerfile -t platform-arch-lab:alpine3.22 scripts/deps
./scripts/run-container.sh user
./scripts/run-container.sh startup
./scripts/run-container.sh shell
```

The shell opens at /work inside an isolated container. Exit closes it. Each
suite also creates a disposable container with networking disabled and only
this directory mounted. No container socket or host network is mounted.
The `user` suite runs core/Linux, feature-disabled, public consumer, mechanism,
deadline mutation and bounded ABBA counterexample checks. It does not download
or run FreeRTOS. `startup` adds deterministic startup-order and thread-create
failure injection to the Linux runtime test; these hooks are absent in normal
builds. Both test binaries also compare direct same-fd dup2 with the special
posix_spawn same-fd action and check fixed-fd backend roundtrips.

## One mechanism at a time

Inside the tool container:

```sh
make -C labs all
./build/labs/mechanisms --list
./build/labs/mechanisms fd
./build/labs/mechanisms epoll
./build/labs/mechanisms memory
make test
make startup-test
make -C platform libraries
make -C labs test
cat build/labs/elf-header.txt
make check-docs
make package
```

Selection names: fd, rollback, save, ipc, blocking, stream, epoll, partial-write,
queue, atomic, memory, extra. Each checks its own assertions and descriptor
baseline; `all` runs the full set. Page-fault counts depend on the kernel.
Output lines describe assertion results, not general real-time guarantees.
`make package` regenerates a source archive from SOURCEFILES.json's file list,
excluding build output and downloaded dependencies.

## FreeRTOS and optional checks

FreeRTOS-Kernel V11.1.0 is downloaded separately and checked against the pinned
SHA256 in scripts/deps/fetch-freertos.sh. Fetch in a temporary container with
ordinary outbound networking, then run the test without networking:

```sh
./scripts/run-container.sh deps
./scripts/run-container.sh freertos
docker build -f scripts/deps/Dockerfile.sanitizers -t platform-arch-sanitizers:bookworm scripts/deps
./scripts/run-container.sh sanitize
./scripts/run-container.sh tsan
./scripts/run-container.sh benchmark
```

The FreeRTOS POSIX port exercises the actual scheduler/tasks/queues on Linux;
it does not establish MCU interrupt latency or hardware timing. The sanitizer
image is separate. A TSan address-layout incompatibility is recorded as SKIP,
not PASS. The TSan container alone uses seccomp=unconfined when required by
the detector. Normal suites retain the default profile. Benchmark generates
five rounds each for request limits 4 and 16, followed by summary.json.
Results and exact command exit codes are saved under build/verification.
`./scripts/run-container.sh reproduction` checks the public Markdown targets,
source repackaging and the fd/epoll/memory single-experiment commands.

## Networking and kernel

`./scripts/run-container.sh network` adds NET_ADMIN and SYS_ADMIN only to its
disposable container for private network namespaces and TAP. It verifies local
delivery, captured ARP/ICMP, delay and selected EtherType dropping.

The provided VM builder currently targets ARM64 Alpine/musl. Use an ARM64
Docker host/image for `./scripts/run-container.sh kernel-build`. The script
refuses a mismatched userspace architecture; it builds modules but never loads
them in the host/container kernel. Run `python3 kernel-labs/run-vm.py` on a
host with qemu-system-aarch64; the guest has no NIC and uses TCG. Serial output
is saved at build/vm/serial.log. Other architectures require a matched kernel,
module toolchain, initramfs loader and QEMU machine; merely changing cc is
insufficient. No target board, MCU timing, KASAN or lockdep result is implied.

## API boundary and licensing

create/start/destroy are serialized by the application. submit/cancel/recover/
post_stop/snapshot may have multiple producers. The owner exclusively mutates
core; callbacks run without the internal mutex. Synchronous stop, stop_wait
and destroy from an owner callback return SDK_ECONTEXT; post_stop is allowed.
Payload is copied on submit; callback payload expires at callback return.
A successful enqueue produces ACCEPT or REJECT; only accepted requests owe a
single TERMINAL. A timed-out stop leaves the object valid for a later wait.
destroy requires every external API caller to have finished.

Self-authored code is MIT (LICENSE). archlab.c declares GPL-2.0-only and must
retain that module license. FreeRTOS is a separate upstream MIT dependency;
its original license remains with the fetched files. No prebuilt libraries or
third-party source are included; compile for the target architecture/libc.
SOURCEFILES.json lists every public file and its SHA256.
