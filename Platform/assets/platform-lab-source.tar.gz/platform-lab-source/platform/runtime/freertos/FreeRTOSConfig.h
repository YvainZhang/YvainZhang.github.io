#ifndef FREERTOS_CONFIG_H
#define FREERTOS_CONFIG_H
#include <assert.h>
#include <stdint.h>
#define configUSE_PREEMPTION 1
#define configUSE_TIME_SLICING 1
#define configUSE_IDLE_HOOK 0
#define configUSE_TICK_HOOK 0
#define configTICK_RATE_HZ 1000
#define configCPU_CLOCK_HZ 100000000
#define configMAX_PRIORITIES 6
#define configMINIMAL_STACK_SIZE 4096
#define configTOTAL_HEAP_SIZE (4 * 1024 * 1024)
#define configMAX_TASK_NAME_LEN 24
#define configUSE_16_BIT_TICKS 0
#define configIDLE_SHOULD_YIELD 1
#define configUSE_MUTEXES 1
#define configUSE_RECURSIVE_MUTEXES 0
#define configUSE_COUNTING_SEMAPHORES 1
#define configUSE_TASK_NOTIFICATIONS 1
#define configSUPPORT_DYNAMIC_ALLOCATION 1
#define configSUPPORT_STATIC_ALLOCATION 1
#define configUSE_TIMERS 1
#define configTIMER_TASK_PRIORITY 3
#define configTIMER_QUEUE_LENGTH 16
#define configTIMER_TASK_STACK_DEPTH 4096
#define configCHECK_FOR_STACK_OVERFLOW 0
#define configUSE_MALLOC_FAILED_HOOK 0
#define configQUEUE_REGISTRY_SIZE 0
#define INCLUDE_vTaskDelete 1
#define INCLUDE_uxTaskPriorityGet 1
#define INCLUDE_vTaskDelay 1
#define INCLUDE_vTaskSuspend 1
#define INCLUDE_xTaskGetCurrentTaskHandle 1
#define INCLUDE_xTaskGetSchedulerState 1
#define INCLUDE_uxTaskGetStackHighWaterMark 1
#define configASSERT(x) assert(x)
#endif
