#include "FreeRTOS.h"
#include "queue.h"
#include "sdk_core.h"
#include "semphr.h"
#include "task.h"
#include <limits.h>
#include <string.h>
struct sdk {
    int send_error;
    struct sdk_key send_error_key;
    struct sdk_core core;
    struct sdk_config config;
    sdk_callback callback;
    void *context;
    QueueHandle_t ingress, commands, replies, data;
    StaticQueue_t ingress_cb, commands_cb, replies_cb, data_cb;
    uint8_t ingress_storage[SDK_INGRESS * sizeof(struct core_event)];
    uint8_t command_storage[SDK_REQUESTS * sizeof(struct core_event)];
    uint8_t reply_storage[SDK_REQUESTS * 2 * sizeof(struct core_event)];
    uint8_t data_storage[SDK_DATA_ITEMS * sizeof(struct core_event)];
    SemaphoreHandle_t mutex, join_mutex, owner_done, device_done;
    TaskHandle_t owner, device;
    int started, joined, accepting, stop, device_stop, reset_pending, reset_fail;
    uint64_t next_id, backend_generated, backend_dropped, seen_generated, seen_dropped;
    uint32_t epoch;
    struct sdk_stats snapshot;
    enum sdk_state snapshot_state;
};
struct scheduled {
    int used;
    uint64_t due;
    struct core_event event;
};
static uint64_t now_ms(void) { return (uint64_t)xTaskGetTickCount() * 1000 / configTICK_RATE_HZ; }
static void lock(struct sdk *s) { configASSERT(xSemaphoreTake(s->mutex, portMAX_DELAY) == pdTRUE); }
static void unlock(struct sdk *s) { xSemaphoreGive(s->mutex); }
static void sink(void *ctx, const struct core_action *a) {
    struct sdk *s = ctx;
    if (a->type == A_NOTICE) {
        if (s->callback)
            s->callback(s->context, &a->notice);
    } else if (a->type == A_RESET) {
        s->reset_pending = 1;
        s->reset_fail = (a->flags & SDK_F_RECOVER_FAIL) != 0;
    } else if (a->type == A_CLOSE) {
        lock(s);
        s->device_stop = 1;
        unlock(s);
    } else if (a->type == A_SEND) {
        struct core_event e;
        memset(&e, 0, sizeof(e));
        e.type = C_SUBMIT;
        e.key = a->key;
        e.flags = a->flags;
        e.length = a->length;
        memcpy(e.payload, a->payload, a->length);
        if (xQueueSend(s->commands, &e, 0) !=
            pdTRUE) { /* Deferred failure avoids recursive core calls. */
            s->send_error = SDK_EFULL;
            s->send_error_key = a->key;
        }
    }
}
static void device_task(void *ctx) {
    struct sdk *s = ctx;
    struct scheduled slots[SDK_REQUESTS * 2];
    memset(slots, 0, sizeof(slots));
    uint64_t seq = 0;
    for (;;) {
        lock(s);
        int stop = s->device_stop;
        unlock(s);
        if (stop)
            break;
        uint64_t now = now_ms();
        for (size_t i = 0; i < SDK_REQUESTS * 2; i++)
            if (slots[i].used && now >= slots[i].due) {
                if (xQueueSend(s->replies, &slots[i].event, 0) == pdTRUE) {
                    xTaskNotifyGive(s->owner);
                    if (slots[i].event.flags & SDK_F_DUP) {
                        slots[i].event.flags &= ~SDK_F_DUP;
                        slots[i].due = now + 2;
                    } else
                        slots[i].used = 0;
                }
            }
        struct core_event e;
        if (xQueueReceive(s->commands, &e, pdMS_TO_TICKS(1)) != pdTRUE)
            continue;
        if (e.flags & SDK_F_DISCONNECT) {
            e.type = C_DISCONNECT;
            xQueueSend(s->replies, &e, portMAX_DELAY);
            xTaskNotifyGive(s->owner);
            continue;
        }
        if (e.flags & SDK_F_STREAM) {
            unsigned dropped = 0;
            vTaskSuspendAll();
            for (unsigned i = 0; i < 80; i++) {
                struct core_event d;
                memset(&d, 0, sizeof(d));
                d.type = C_DATA;
                d.key = e.key;
                d.sequence = ++seq;
                d.length = 32;
                memset(d.payload, (int)(seq & 255), 32);
                /* Nonblocking queue: core records data arrival/drop even under upstream overload
                 * via separate aggregate. */
                if (xQueueSend(s->data, &d, 0) != pdTRUE)
                    dropped++;
            }
            xTaskResumeAll();
            lock(s);
            s->backend_generated += 80;
            s->backend_dropped += dropped;
            unlock(s);
            xTaskNotifyGive(s->owner);
        }
        if (e.flags & SDK_F_DROP)
            continue;
        for (size_t i = 0; i < SDK_REQUESTS * 2; i++)
            if (!slots[i].used) {
                slots[i].used = 1;
                slots[i].due = now_ms() + ((e.flags & SDK_F_DELAY) ? 200 : 5);
                slots[i].event = e;
                slots[i].event.type = (e.flags & SDK_F_BAD_VERSION) ? C_MALFORMED : C_RESPONSE;
                break;
            }
    }
    xSemaphoreGive(s->device_done);
    vTaskDelete(NULL);
}
static void publish(struct sdk *s) {
    lock(s);
    s->snapshot = s->core.stats;
    s->snapshot_state = s->core.state;
    if (s->epoch != s->core.generation)
        s->next_id = 1;
    s->epoch = s->core.generation;
    s->accepting = s->core.state == SDK_READY && !s->stop;
    unlock(s);
}
static void owner_task(void *ctx) {
    struct sdk *s = ctx;
    struct core_event e = {.type = C_READY};
    core_event(&s->core, &e);
    publish(s);
    for (;;) {
        lock(s);
        int stop = s->stop;
        unlock(s);
        if (stop) {
            e.type = C_STOP;
            core_event(&s->core, &e);
        }
        for (unsigned i = 0; i < SDK_INGRESS || s->core.state == SDK_CLOSED; i++) {
            if (xQueueReceive(s->ingress, &e, 0) != pdTRUE)
                break;
            lock(s);
            stop = s->stop;
            unlock(s);
            if (stop && s->core.state != SDK_CLOSED) {
                struct core_event end = {.type = C_STOP};
                core_event(&s->core, &end);
            }
            e.now = now_ms();
            core_event(&s->core, &e);
            if (s->send_error) {
                struct core_event failed = {.type = C_RESPONSE,
                                            .key = s->send_error_key,
                                            .now = e.now,
                                            .status = s->send_error};
                s->send_error = 0;
                core_event(&s->core, &failed);
            }
            if (s->reset_pending) {
                s->reset_pending = 0;
                struct core_event ready = {.type = s->reset_fail ? C_DISCONNECT : C_READY};
                core_event(&s->core, &ready);
            }
        }
        for (unsigned i = 0; i < 32; i++) {
            if (xQueueReceive(s->replies, &e, 0) != pdTRUE)
                break;
            e.now = now_ms();
            core_event(&s->core, &e);
        }
        for (unsigned i = 0; i < 32; i++) {
            if (xQueueReceive(s->data, &e, 0) != pdTRUE)
                break;
            e.now = now_ms();
            core_event(&s->core, &e);
        }
        lock(s);
        struct core_event counts = {.type = C_BACKEND_COUNTS,
                                    .sequence = s->backend_generated - s->seen_generated,
                                    .deadline = s->backend_dropped - s->seen_dropped};
        s->seen_generated = s->backend_generated;
        s->seen_dropped = s->backend_dropped;
        unlock(s);
        core_event(&s->core, &counts);
        e.type = C_TICK;
        e.now = now_ms();
        core_event(&s->core, &e);
        for (unsigned i = 0; i < 8; i++) {
            e.type = C_CONSUME;
            if (core_event(&s->core, &e) == SDK_EMPTY)
                break;
        }
        publish(s);
        configASSERT(core_invariant(&s->core));
        if (s->core.state == SDK_CLOSED)
            break;
        ulTaskNotifyTake(pdTRUE, pdMS_TO_TICKS(1));
    }
    /* Backend task must end before any queue or runtime storage is destroyed. */
    xSemaphoreTake(s->device_done, portMAX_DELAY);
    publish(s);
    xSemaphoreGive(s->owner_done);
    vTaskDelete(NULL);
}
int sdk_create(struct sdk **out, const struct sdk_config *cfg, const char *sim, sdk_callback cb,
               void *ctx) {
    (void)sim;
    if (!out || !cfg)
        return SDK_EINVAL;
    *out = NULL;
    struct sdk *s = pvPortMalloc(sizeof(*s));
    if (!s)
        return SDK_EIO;
    memset(s, 0, sizeof(*s));
    s->config = *cfg;
    s->callback = cb;
    s->context = ctx;
    s->epoch = 1;
    s->next_id = 1;
    s->snapshot_state = SDK_STARTING;
    if (core_init(&s->core, cfg, sink, s) != SDK_OK) {
        vPortFree(s);
        return SDK_EINVAL;
    }
    s->mutex = xSemaphoreCreateMutex();
    s->join_mutex = xSemaphoreCreateMutex();
    s->owner_done = xSemaphoreCreateBinary();
    s->device_done = xSemaphoreCreateBinary();
    if (!s->mutex || !s->join_mutex || !s->owner_done || !s->device_done) {
        if (s->mutex)
            vSemaphoreDelete(s->mutex);
        if (s->join_mutex)
            vSemaphoreDelete(s->join_mutex);
        if (s->owner_done)
            vSemaphoreDelete(s->owner_done);
        if (s->device_done)
            vSemaphoreDelete(s->device_done);
        vPortFree(s);
        return SDK_EIO;
    }
    s->ingress = xQueueCreateStatic(SDK_INGRESS, sizeof(struct core_event), s->ingress_storage,
                                    &s->ingress_cb);
    s->commands = xQueueCreateStatic(SDK_REQUESTS, sizeof(struct core_event), s->command_storage,
                                     &s->commands_cb);
    s->replies = xQueueCreateStatic(SDK_REQUESTS * 2, sizeof(struct core_event), s->reply_storage,
                                    &s->replies_cb);
    s->data =
        xQueueCreateStatic(SDK_DATA_ITEMS, sizeof(struct core_event), s->data_storage, &s->data_cb);
    *out = s;
    return SDK_OK;
}
int sdk_start(struct sdk *s) {
    if (!s || s->started)
        return SDK_ESTATE;
    /* Scheduler suspends startup so device cannot notify an uninitialized owner. */
    vTaskSuspendAll();
    BaseType_t o = xTaskCreate(owner_task, "sdk-owner", 8192, s, 3, &s->owner);
    BaseType_t d =
        o == pdPASS ? xTaskCreate(device_task, "sdk-device", 8192, s, 2, &s->device) : pdFAIL;
    if (o != pdPASS || d != pdPASS) {
        if (o == pdPASS)
            vTaskDelete(s->owner);
        xTaskResumeAll();
        return SDK_EIO;
    }
    s->started = 1;
    xTaskResumeAll();
    for (unsigned i = 0; i < 3000; i++) {
        lock(s);
        int ready = s->snapshot_state == SDK_READY;
        unlock(s);
        if (ready)
            return SDK_OK;
        vTaskDelay(1);
    }
    sdk_stop(s);
    return SDK_EIO;
}
int sdk_submit(struct sdk *s, const void *p, size_t len, uint64_t timeout, uint32_t flags,
               struct sdk_key *key) {
#if !SDK_ENABLE_DATA
    if (flags & SDK_F_STREAM)
        return SDK_ENOTSUP;
#endif
    uint64_t now = now_ms();
    if (!s || !key || (!p && len) || len > SDK_CONTROL_MAX || !timeout ||
        timeout > UINT64_MAX - now)
        return SDK_EINVAL;
    struct core_event e;
    memset(&e, 0, sizeof(e));
    e.type = C_SUBMIT;
    e.deadline = now + timeout;
    e.flags = flags;
    e.length = len;
    if (len)
        memcpy(e.payload, p, len);
    lock(s);
    if (!s->accepting) {
        unlock(s);
        return SDK_ESTATE;
    }
    if (s->next_id == UINT64_MAX) {
        unlock(s);
        return SDK_ELIMIT;
    }
    e.key = (struct sdk_key){s->config.instance, s->epoch, s->next_id};
    if (xQueueSend(s->ingress, &e, 0) != pdTRUE) {
        unlock(s);
        return SDK_EFULL;
    }
    s->next_id++;
    *key = e.key;
    unlock(s);
    xTaskNotifyGive(s->owner);
    return SDK_QUEUED;
}
static int enqueue(struct sdk *s, struct core_event *e, int recovery) {
    if (!s)
        return SDK_EINVAL;
    lock(s);
    if ((!s->accepting && !recovery) || s->stop || !s->started) {
        unlock(s);
        return SDK_ESTATE;
    }
    if (xQueueSend(s->ingress, e, 0) != pdTRUE) {
        unlock(s);
        return SDK_EFULL;
    }
    if (recovery)
        s->accepting = 0;
    unlock(s);
    xTaskNotifyGive(s->owner);
    return SDK_QUEUED;
}
int sdk_cancel(struct sdk *s, struct sdk_key key) {
    struct core_event e = {.type = C_CANCEL, .key = key};
    return enqueue(s, &e, 0);
}
int sdk_recover(struct sdk *s, int fail) {
    struct core_event e = {.type = C_RECOVER, .flags = fail ? SDK_F_RECOVER_FAIL : 0};
    return enqueue(s, &e, 1);
}
int sdk_post_stop(struct sdk *s) {
    if (!s)
        return SDK_EINVAL;
    lock(s);
    s->stop = 1;
    s->accepting = 0;
    unlock(s);
    if (s->started && !s->joined)
        xTaskNotifyGive(s->owner);
    return SDK_OK;
}
int sdk_stop(struct sdk *s) {
    if (!s)
        return SDK_EINVAL;
    if (s->started && xTaskGetCurrentTaskHandle() == s->owner)
        return SDK_ECONTEXT;
    xSemaphoreTake(s->join_mutex, portMAX_DELAY);
    sdk_post_stop(s);
    if (s->started && !s->joined) {
        xSemaphoreTake(s->owner_done, portMAX_DELAY);
        s->joined = 1;
    }
    xSemaphoreGive(s->join_mutex);
    return SDK_OK;
}
int sdk_snapshot(struct sdk *s, struct sdk_stats *stats, enum sdk_state *state) {
    if (!s)
        return SDK_EINVAL;
    lock(s);
    if (stats)
        *stats = s->snapshot;
    if (state)
        *state = s->snapshot_state;
    unlock(s);
    return SDK_OK;
}
struct sdk_caps sdk_capabilities(const struct sdk *s) {
    struct sdk_caps c = {SDK_API_VERSION,
                         SDK_CONTROL_MAX,
                         SDK_ENABLE_DATA ? SDK_DATA_MAX : 0,
                         s ? s->config.request_limit : 0,
                         0,
                         0};
    return c;
}
int sdk_destroy(struct sdk *s) {
    if (!s)
        return SDK_EINVAL;
    int r = sdk_stop(s);
    if (r)
        return r;
    vQueueDelete(s->ingress);
    vQueueDelete(s->commands);
    vQueueDelete(s->replies);
    vQueueDelete(s->data);
    vSemaphoreDelete(s->mutex);
    vSemaphoreDelete(s->join_mutex);
    vSemaphoreDelete(s->owner_done);
    vSemaphoreDelete(s->device_done);
    vPortFree(s);
    return SDK_OK;
}

struct sdk_budget sdk_resource_budget(const struct sdk *s) {
    struct sdk_budget b = {sizeof(struct sdk_core), s ? sizeof(*s) : 0, 8192 * sizeof(StackType_t),
                           8192 * sizeof(StackType_t)};
    return b;
}

int sdk_stop_wait(struct sdk *s, uint32_t timeout_ms) {
    if (!s || !timeout_ms)
        return SDK_EINVAL;
    if (s->started && xTaskGetCurrentTaskHandle() == s->owner)
        return SDK_ECONTEXT;
    if (xSemaphoreTake(s->join_mutex, 0) != pdTRUE)
        return SDK_EFULL;
    sdk_post_stop(s);
    int result = SDK_OK;
    if (s->started && !s->joined) {
        TickType_t ticks = (TickType_t)(((uint64_t)timeout_ms * configTICK_RATE_HZ + 999) / 1000);
        if (xSemaphoreTake(s->owner_done, ticks) != pdTRUE)
            result = SDK_ETIME;
        else
            s->joined = 1;
    }
    xSemaphoreGive(s->join_mutex);
    return result;
}
