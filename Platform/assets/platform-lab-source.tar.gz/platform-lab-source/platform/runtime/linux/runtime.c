#define _GNU_SOURCE
#include "sdk_core.h"
#include "sdk_wire.h"
#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <pthread.h>
#include <signal.h>
#include <spawn.h>
#include <stdlib.h>
#include <string.h>
#include <sys/epoll.h>
#include <sys/eventfd.h>
#include <sys/socket.h>
#include <sys/timerfd.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>
extern char **environ;
#ifdef SDK_TEST_STARTUP
/* Deterministic scheduling/failure seams; absent from production builds. */
extern void sdk_linux_test_owner_started(void);
extern void sdk_linux_test_before_publish(void);
extern int sdk_linux_test_create_error(void);
#endif
struct packet {
    size_t length;
    uint8_t bytes[WIRE_MAX];
};
struct sdk {
    int send_error;
    struct sdk_key send_error_key;

    struct sdk_core core;
    struct sdk_config config;
    pthread_mutex_t mutex, join_mutex;
    pthread_cond_t changed;
    pthread_t owner;
    int started, joined, done, accepting, stop_requested;
    int wake, timer, epoll, socket;
    pid_t child;
    uint32_t epoch;
    uint64_t next_id, backend_seen, backend_dropped_seen;
    char simulator[PATH_MAX];
    sdk_callback callback;
    void *context;
    struct core_event ingress[SDK_INGRESS];
    size_t head, count;
    struct packet out[SDK_REQUESTS];
    size_t out_head, out_count;
    struct sdk_stats snapshot;
    enum sdk_state snapshot_state;
};
static uint64_t millis(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (uint64_t)ts.tv_sec * 1000 + (uint64_t)ts.tv_nsec / 1000000;
}
static void wake_owner(struct sdk *s) {
    uint64_t one = 1;
    ssize_t n = write(s->wake, &one, sizeof(one));
    (void)n;
}
static void backend_close(struct sdk *s) {
    if (s->socket >= 0) {
        epoll_ctl(s->epoll, EPOLL_CTL_DEL, s->socket, NULL);
        close(s->socket);
        s->socket = -1;
    }
    s->out_count = 0;
    s->out_head = 0;
    if (s->child > 0) {
        uint64_t deadline = millis() + 500;
        int status;
        pid_t n;
        do {
            n = waitpid(s->child, &status, WNOHANG);
            if (n != 0)
                break;
            struct timespec pause = {0, 1000000};
            nanosleep(&pause, NULL);
        } while (millis() < deadline);
        if (n == 0) {
            kill(s->child, SIGTERM);
            while (waitpid(s->child, &status, 0) < 0 && errno == EINTR) {
            }
        }
        s->child = 0;
    }
}
static int backend_open(struct sdk *s) {
    int fds[2];
    if (socketpair(AF_UNIX, SOCK_SEQPACKET | SOCK_CLOEXEC | SOCK_NONBLOCK, 0, fds) < 0)
        return SDK_EIO;
    /* Normalize the source to a distinct fd. This is defensive, not required by
       posix_spawn: its same-fd dup2 action clears CLOEXEC, unlike direct dup2. */
    if (fds[1] == 198) {
        int source = fcntl(fds[1], F_DUPFD_CLOEXEC, 199);
        if (source < 0) {
            close(fds[0]);
            close(fds[1]);
            return SDK_EIO;
        }
        close(fds[1]);
        fds[1] = source;
    }
    posix_spawn_file_actions_t actions;
    if (posix_spawn_file_actions_init(&actions)) {
        close(fds[0]);
        close(fds[1]);
        return SDK_EIO;
    }
    int err = posix_spawn_file_actions_adddup2(&actions, fds[1], 198);
    char *args[] = {s->simulator, "--fd", "198", NULL};
    if (!err)
        err = posix_spawn(&s->child, s->simulator, &actions, NULL, args, environ);
    posix_spawn_file_actions_destroy(&actions);
    close(fds[1]);
    if (err) {
        close(fds[0]);
        s->child = 0;
        return SDK_EIO;
    }
    s->socket = fds[0];
    s->backend_seen = s->backend_dropped_seen = 0;
    struct epoll_event ev = {.events = EPOLLIN | EPOLLRDHUP, .data.u32 = 3};
    if (epoll_ctl(s->epoll, EPOLL_CTL_ADD, s->socket, &ev) < 0) {
        backend_close(s);
        return SDK_EIO;
    }
    return SDK_OK;
}
static void watch_output(struct sdk *s) {
    if (s->socket < 0)
        return;
    struct epoll_event ev = {.events = EPOLLIN | EPOLLRDHUP | (s->out_count ? EPOLLOUT : 0),
                             .data.u32 = 3};
    epoll_ctl(s->epoll, EPOLL_CTL_MOD, s->socket, &ev);
}
static void sink(void *context, const struct core_action *a) {
    struct sdk *s = context;
    if (a->type == A_NOTICE) {
        if (s->callback)
            s->callback(s->context, &a->notice);
        return;
    }
    if (a->type == A_CLOSE) {
        backend_close(s);
        return;
    }
    if (a->type == A_RESET) {
        backend_close(s);
        if ((a->flags & SDK_F_RECOVER_FAIL) || backend_open(s) != SDK_OK) {
            /* Failure is posted, never recursively dispatched into core. */
            pthread_mutex_lock(&s->mutex);
            s->accepting = 0;
            pthread_mutex_unlock(&s->mutex);
        }
        return;
    }
    if (a->type == A_SEND) {
        if (s->socket < 0 || s->out_count >= SDK_REQUESTS) {
            s->send_error = s->socket < 0 ? SDK_EIO : SDK_EFULL;
            s->send_error_key = a->key;
            return;
        }
        struct packet *p = &s->out[(s->out_head + s->out_count) % SDK_REQUESTS];
        struct wire_message m;
        memset(&m, 0, sizeof(m));
        m.type = W_REQUEST;
        m.key = a->key;
        m.flags = a->flags;
        m.length = a->length;
        memcpy(m.payload, a->payload, a->length);
        if (wire_encode(p->bytes, sizeof(p->bytes), &m, &p->length) == SDK_OK) {
            s->out_count++;
            watch_output(s);
        }
    }
}
static void publish(struct sdk *s) {
    pthread_mutex_lock(&s->mutex);
    s->snapshot = s->core.stats;
    s->snapshot_state = s->core.state;
    if (s->epoch != s->core.generation)
        s->next_id = 1;
    s->epoch = s->core.generation;
    if (s->core.state == SDK_READY && !s->stop_requested)
        s->accepting = 1;
    else
        s->accepting = 0;
    pthread_cond_broadcast(&s->changed);
    pthread_mutex_unlock(&s->mutex);
}
static void disconnect(struct sdk *s) {
    backend_close(s);
    struct core_event e = {.type = C_DISCONNECT};
    core_event(&s->core, &e);
}
static void output(struct sdk *s) {
    while (s->out_count) {
        struct packet *p = &s->out[s->out_head];
        ssize_t n = send(s->socket, p->bytes, p->length, MSG_NOSIGNAL);
        if (n < 0 && (errno == EAGAIN || errno == EWOULDBLOCK))
            break;
        if (n < 0 || n != (ssize_t)p->length) {
            disconnect(s);
            return;
        }
        s->out_head = (s->out_head + 1) % SDK_REQUESTS;
        s->out_count--;
    }
    watch_output(s);
}
static void input(struct sdk *s) {
    for (unsigned budget = 0; budget < 32 && s->socket >= 0; budget++) {
        uint8_t buf[WIRE_MAX];
        ssize_t n = recv(s->socket, buf, sizeof(buf), MSG_TRUNC);
        if (n < 0 && (errno == EAGAIN || errno == EWOULDBLOCK))
            break;
        if (n < 0 && errno == EINTR)
            continue;
        if (n <= 0) {
            disconnect(s);
            return;
        }
        struct wire_message m;
        struct core_event e;
        memset(&e, 0, sizeof(e));
        e.now = millis();
        if (n > (ssize_t)sizeof(buf) || wire_decode(&m, buf, (size_t)n) != SDK_OK) {
            e.type = C_MALFORMED;
            core_event(&s->core, &e);
            continue;
        }
        e.key = m.key;
        e.length = m.length;
        e.sequence = m.sequence;
        e.status = m.status;
        memcpy(e.payload, m.payload, m.length);
        switch (m.type) {
        case W_HELLO:
            e.type = C_READY;
            break;
        case W_RESPONSE:
            if (m.key.generation == s->core.generation && m.sequence >= s->backend_seen &&
                m.backend_dropped >= s->backend_dropped_seen) {
                struct core_event counts = {.type = C_BACKEND_COUNTS,
                                            .sequence = m.sequence - s->backend_seen,
                                            .deadline =
                                                m.backend_dropped - s->backend_dropped_seen};
                core_event(&s->core, &counts);
                s->backend_seen = m.sequence;
                s->backend_dropped_seen = m.backend_dropped;
            }
            e.type = C_RESPONSE;
            break;
        case W_DATA:
            e.type = C_DATA;
            break;
        default:
            e.type = C_MALFORMED;
            break;
        }
        core_event(&s->core, &e);
    }
}
static void *owner(void *ctx) {
    struct sdk *s = ctx;
#ifdef SDK_TEST_STARTUP
    sdk_linux_test_owner_started();
#endif
    /* The first mutex acquisition below waits for sdk_start to publish owner
       and started. No core action or user callback can precede publication. */
    while (s->core.state != SDK_CLOSED) {
        pthread_mutex_lock(&s->mutex);
        int stop = s->stop_requested;
        pthread_mutex_unlock(&s->mutex);
        if (stop) {
            struct core_event e = {.type = C_STOP};
            core_event(&s->core, &e);
        }
        for (unsigned budget = 0; budget < SDK_INGRESS || s->core.state == SDK_CLOSED; budget++) {
            struct core_event e;
            pthread_mutex_lock(&s->mutex);
            if (!s->count) {
                pthread_mutex_unlock(&s->mutex);
                break;
            }
            stop = s->stop_requested;
            e = s->ingress[s->head];
            s->head = (s->head + 1) % SDK_INGRESS;
            s->count--;
            pthread_mutex_unlock(&s->mutex);
            if (stop && s->core.state != SDK_CLOSED) {
                struct core_event end = {.type = C_STOP};
                core_event(&s->core, &end);
            }
            e.now = millis();
            core_event(&s->core, &e);
            if (s->send_error) {
                struct core_event failed = {.type = C_RESPONSE,
                                            .key = s->send_error_key,
                                            .now = e.now,
                                            .status = s->send_error};
                s->send_error = 0;
                core_event(&s->core, &failed);
            }
            if (e.type == C_RECOVER && s->socket < 0 && s->core.state != SDK_CLOSED) {
                struct core_event f = {.type = C_DISCONNECT};
                core_event(&s->core, &f);
            }
        }
        struct core_event tick = {.type = C_TICK, .now = millis()};
        core_event(&s->core, &tick);
        for (unsigned i = 0; i < 8; i++) {
            struct core_event e = {.type = C_CONSUME};
            if (core_event(&s->core, &e) == SDK_EMPTY)
                break;
        }
        publish(s);
        if (s->core.state == SDK_CLOSED)
            break;
        struct epoll_event events[4];
        int n = epoll_wait(s->epoll, events, 4, -1);
        if (n < 0) {
            if (errno == EINTR)
                continue;
            disconnect(s);
            break;
        }
        for (int i = 0; i < n; i++) {
            uint64_t count;
            if (events[i].data.u32 == 1) {
                while (read(s->wake, &count, sizeof(count)) > 0) {
                }
            } else if (events[i].data.u32 == 2) {
                while (read(s->timer, &count, sizeof(count)) > 0) {
                }
            } else if (events[i].data.u32 == 3 && s->socket >= 0) {
                if (events[i].events & EPOLLIN)
                    input(s);
                if (s->socket >= 0 && (events[i].events & EPOLLOUT))
                    output(s);
                if (s->socket >= 0 && (events[i].events & (EPOLLRDHUP | EPOLLHUP | EPOLLERR)))
                    input(s);
            }
        }
    }
    /* Close admission before the final drain, including fatal epoll exits. */
    pthread_mutex_lock(&s->mutex);
    s->accepting = 0;
    s->stop_requested = 1;
    pthread_mutex_unlock(&s->mutex);
    if (s->core.state != SDK_CLOSED) {
        struct core_event e = {.type = C_STOP};
        core_event(&s->core, &e);
    }
    for (;;) {
        struct core_event pending;
        pthread_mutex_lock(&s->mutex);
        if (!s->count) {
            pthread_mutex_unlock(&s->mutex);
            break;
        }
        pending = s->ingress[s->head];
        s->head = (s->head + 1) % SDK_INGRESS;
        s->count--;
        pthread_mutex_unlock(&s->mutex);
        pending.now = millis();
        core_event(&s->core, &pending);
    }
    pthread_mutex_lock(&s->mutex);
    s->done = 1;
    s->accepting = 0;
    s->snapshot = s->core.stats;
    s->snapshot_state = s->core.state;
    pthread_cond_broadcast(&s->changed);
    pthread_mutex_unlock(&s->mutex);
    return NULL;
}
int sdk_create(struct sdk **out, const struct sdk_config *cfg, const char *sim, sdk_callback cb,
               void *ctx) {
    if (!out || !cfg || !sim || strlen(sim) >= PATH_MAX)
        return SDK_EINVAL;
    *out = NULL;
    struct sdk *s = calloc(1, sizeof(*s));
    if (!s)
        return SDK_EIO;
    s->wake = s->timer = s->epoll = s->socket = -1;
    s->config = *cfg;
    s->callback = cb;
    s->context = ctx;
    s->next_id = 1;
    s->epoch = 1;
    memcpy(s->simulator, sim, strlen(sim) + 1);
    if (core_init(&s->core, cfg, sink, s) != SDK_OK) {
        free(s);
        return SDK_EINVAL;
    }
    if (pthread_mutex_init(&s->mutex, NULL)) {
        free(s);
        return SDK_EIO;
    }
    if (pthread_mutex_init(&s->join_mutex, NULL)) {
        pthread_mutex_destroy(&s->mutex);
        free(s);
        return SDK_EIO;
    }
    pthread_condattr_t condattr;
    if (pthread_condattr_init(&condattr)) {
        pthread_mutex_destroy(&s->join_mutex);
        pthread_mutex_destroy(&s->mutex);
        free(s);
        return SDK_EIO;
    }
    int cond_error = pthread_condattr_setclock(&condattr, CLOCK_MONOTONIC);
    if (!cond_error)
        cond_error = pthread_cond_init(&s->changed, &condattr);
    pthread_condattr_destroy(&condattr);
    if (cond_error) {
        pthread_mutex_destroy(&s->join_mutex);
        pthread_mutex_destroy(&s->mutex);
        free(s);
        return SDK_EIO;
    }
    s->snapshot_state = SDK_STARTING;
    *out = s;
    return SDK_OK;
}
int sdk_start(struct sdk *s) {
    if (!s || s->started)
        return SDK_ESTATE;
    s->wake = eventfd(0, EFD_NONBLOCK | EFD_CLOEXEC);
    s->timer = timerfd_create(CLOCK_MONOTONIC, TFD_NONBLOCK | TFD_CLOEXEC);
    s->epoll = epoll_create1(EPOLL_CLOEXEC);
    if (s->wake < 0 || s->timer < 0 || s->epoll < 0)
        goto fail;
    struct epoll_event e = {.events = EPOLLIN, .data.u32 = 1};
    if (epoll_ctl(s->epoll, EPOLL_CTL_ADD, s->wake, &e) < 0)
        goto fail;
    e.data.u32 = 2;
    if (epoll_ctl(s->epoll, EPOLL_CTL_ADD, s->timer, &e) < 0)
        goto fail;
    struct itimerspec interval = {.it_interval = {0, 1000000}, .it_value = {0, 1000000}};
    if (timerfd_settime(s->timer, 0, &interval, NULL) < 0 || backend_open(s) != SDK_OK)
        goto fail;
    pthread_attr_t attr;
    if (pthread_attr_init(&attr))
        goto fail;
    int created = pthread_attr_setstacksize(&attr, 256 * 1024);
    pthread_mutex_lock(&s->mutex);
#ifdef SDK_TEST_STARTUP
    if (!created)
        created = sdk_linux_test_create_error();
#endif
    if (!created)
        created = pthread_create(&s->owner, &attr, owner, s);
    pthread_attr_destroy(&attr);
    if (created) {
        pthread_mutex_unlock(&s->mutex);
        goto fail;
    }
#ifdef SDK_TEST_STARTUP
    sdk_linux_test_before_publish();
#endif
    s->started = 1;
    struct timespec until;
    clock_gettime(CLOCK_MONOTONIC, &until);
    until.tv_sec += 3;
    while (s->snapshot_state == SDK_STARTING && !s->done) {
        int r = pthread_cond_timedwait(&s->changed, &s->mutex, &until);
        if (r == ETIMEDOUT)
            break;
    }
    int ready = s->snapshot_state == SDK_READY;
    pthread_mutex_unlock(&s->mutex);
    if (!ready) {
        sdk_stop(s);
        return SDK_EIO;
    }
    return SDK_OK;
fail:
    backend_close(s);
    if (s->wake >= 0)
        close(s->wake);
    if (s->timer >= 0)
        close(s->timer);
    if (s->epoll >= 0)
        close(s->epoll);
    s->wake = s->timer = s->epoll = -1;
    return SDK_EIO;
}
static int enqueue(struct sdk *s, const struct core_event *e) {
    if (!s)
        return SDK_EINVAL;
    pthread_mutex_lock(&s->mutex);
    if (!s->accepting) {
        pthread_mutex_unlock(&s->mutex);
        return SDK_ESTATE;
    }
    if (s->count == SDK_INGRESS) {
        pthread_mutex_unlock(&s->mutex);
        return SDK_EFULL;
    }
    s->ingress[(s->head + s->count) % SDK_INGRESS] = *e;
    s->count++;
    pthread_mutex_unlock(&s->mutex);
    wake_owner(s);
    return SDK_QUEUED;
}
int sdk_submit(struct sdk *s, const void *p, size_t len, uint64_t timeout, uint32_t flags,
               struct sdk_key *key) {
#if !SDK_ENABLE_DATA
    if (flags & SDK_F_STREAM)
        return SDK_ENOTSUP;
#endif
    uint64_t now = millis();
    if (!s || !key || (!p && len) || len > SDK_CONTROL_MAX || !timeout ||
        timeout > UINT64_MAX - now)
        return SDK_EINVAL;
    struct core_event e;
    memset(&e, 0, sizeof(e));
    e.type = C_SUBMIT;
    e.deadline = now + timeout;
    e.length = len;
    e.flags = flags;
    if (len)
        memcpy(e.payload, p, len);
    pthread_mutex_lock(&s->mutex);
    if (!s->accepting) {
        pthread_mutex_unlock(&s->mutex);
        return SDK_ESTATE;
    }
    if (s->count == SDK_INGRESS) {
        pthread_mutex_unlock(&s->mutex);
        return SDK_EFULL;
    }
    if (s->next_id == UINT64_MAX) {
        pthread_mutex_unlock(&s->mutex);
        return SDK_ELIMIT;
    }
    e.key = (struct sdk_key){s->config.instance, s->epoch, s->next_id++};
    *key = e.key;
    s->ingress[(s->head + s->count) % SDK_INGRESS] = e;
    s->count++;
    pthread_mutex_unlock(&s->mutex);
    wake_owner(s);
    return SDK_QUEUED;
}
int sdk_cancel(struct sdk *s, struct sdk_key key) {
    struct core_event e = {.type = C_CANCEL, .key = key};
    return enqueue(s, &e);
}
int sdk_recover(struct sdk *s, int fail) {
    if (!s)
        return SDK_EINVAL;
    struct core_event e = {.type = C_RECOVER, .flags = fail ? SDK_F_RECOVER_FAIL : 0};
    pthread_mutex_lock(&s->mutex);
    if (!s->started || s->done || s->stop_requested || s->count == SDK_INGRESS) {
        pthread_mutex_unlock(&s->mutex);
        return SDK_ESTATE;
    }
    s->accepting = 0;
    s->ingress[(s->head + s->count) % SDK_INGRESS] = e;
    s->count++;
    pthread_mutex_unlock(&s->mutex);
    wake_owner(s);
    return SDK_QUEUED;
}
int sdk_post_stop(struct sdk *s) {
    if (!s)
        return SDK_EINVAL;
    pthread_mutex_lock(&s->mutex);
    s->accepting = 0;
    s->stop_requested = 1;
    pthread_mutex_unlock(&s->mutex);
    if (s->wake >= 0)
        wake_owner(s);
    return SDK_OK;
}
int sdk_stop(struct sdk *s) {
    if (!s)
        return SDK_EINVAL;
    if (s->started && pthread_equal(pthread_self(), s->owner))
        return SDK_ECONTEXT;
    pthread_mutex_lock(&s->join_mutex);
    sdk_post_stop(s);
    if (s->started && !s->joined) {
        pthread_join(s->owner, NULL);
        s->joined = 1;
    }
    pthread_mutex_unlock(&s->join_mutex);
    return SDK_OK;
}
int sdk_snapshot(struct sdk *s, struct sdk_stats *stats, enum sdk_state *st) {
    if (!s)
        return SDK_EINVAL;
    pthread_mutex_lock(&s->mutex);
    if (stats)
        *stats = s->snapshot;
    if (st)
        *st = s->snapshot_state;
    pthread_mutex_unlock(&s->mutex);
    return SDK_OK;
}
struct sdk_caps sdk_capabilities(const struct sdk *s) {
    struct sdk_caps c = {SDK_API_VERSION,
                         SDK_CONTROL_MAX,
                         SDK_ENABLE_DATA ? SDK_DATA_MAX : 0,
                         s ? s->config.request_limit : 0,
                         0,
                         0};
    return c;
}
int sdk_destroy(struct sdk *s) {
    if (!s)
        return SDK_EINVAL;
    int r = sdk_stop(s);
    if (r)
        return r;
    backend_close(s);
    if (s->wake >= 0)
        close(s->wake);
    if (s->timer >= 0)
        close(s->timer);
    if (s->epoll >= 0)
        close(s->epoll);
    pthread_cond_destroy(&s->changed);
    pthread_mutex_destroy(&s->join_mutex);
    pthread_mutex_destroy(&s->mutex);
    free(s);
    return SDK_OK;
}

struct sdk_budget sdk_resource_budget(const struct sdk *s) {
    struct sdk_budget b = {sizeof(struct sdk_core), s ? sizeof(*s) : 0, 256 * 1024, 0};
    return b;
}

int sdk_stop_wait(struct sdk *s, uint32_t timeout_ms) {
    if (!s || !timeout_ms)
        return SDK_EINVAL;
    if (s->started && pthread_equal(pthread_self(), s->owner))
        return SDK_ECONTEXT;
    if (pthread_mutex_trylock(&s->join_mutex))
        return SDK_EFULL;
    sdk_post_stop(s);
    int result = SDK_OK;
    if (s->started && !s->joined) {
        struct timespec until;
        clock_gettime(CLOCK_MONOTONIC, &until);
        until.tv_sec += timeout_ms / 1000;
        until.tv_nsec += (long)(timeout_ms % 1000) * 1000000;
        if (until.tv_nsec >= 1000000000) {
            until.tv_sec++;
            until.tv_nsec -= 1000000000;
        }
        pthread_mutex_lock(&s->mutex);
        while (!s->done) {
            int e = pthread_cond_timedwait(&s->changed, &s->mutex, &until);
            if (e == ETIMEDOUT) {
                result = SDK_ETIME;
                break;
            }
        }
        pthread_mutex_unlock(&s->mutex);
        if (result == SDK_OK) {
            pthread_join(s->owner, NULL);
            s->joined = 1;
        }
    }
    pthread_mutex_unlock(&s->join_mutex);
    return result;
}
