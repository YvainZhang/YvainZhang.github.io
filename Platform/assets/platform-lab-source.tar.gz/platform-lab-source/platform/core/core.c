#include "sdk_core.h"
#include <limits.h>
#include <string.h>
static int key_eq(struct sdk_key a, struct sdk_key b) {
    return a.instance == b.instance && a.generation == b.generation && a.id == b.id;
}
static void notice(struct sdk_core *c, struct sdk_notice n) {
    struct core_action a;
    memset(&a, 0, sizeof(a));
    a.type = A_NOTICE;
    a.notice = n;
    c->sink(c->context, &a);
}
static void state(struct sdk_core *c, enum sdk_state s) {
    struct sdk_notice n;
    memset(&n, 0, sizeof(n));
    c->state = s;
    n.type = SDK_STATE;
    n.state = s;
    notice(c, n);
}
static void terminal(struct sdk_core *c, struct core_request *r, enum sdk_result result, int status,
                     const uint8_t *p, size_t len) {
    struct sdk_notice n;
    memset(&n, 0, sizeof(n));
    n.type = SDK_TERMINAL;
    n.key = r->key;
    n.result = result;
    n.status = status;
    n.payload = p;
    n.length = len;
    struct core_history *h = &c->history[c->history_next++ % SDK_HISTORY];
    h->key = r->key;
    h->result = result;
    h->valid = 1;
    r->used = 0;
    c->stats.live--;
    switch (result) {
    case SDK_COMPLETED:
        c->stats.completed++;
        break;
    case SDK_TIMED_OUT:
        c->stats.timed_out++;
        break;
    case SDK_CANCELLED:
        c->stats.cancelled++;
        break;
    case SDK_FAILED_RESULT:
        c->stats.failed++;
        break;
    }
    notice(c, n);
}
static void end_all(struct sdk_core *c, enum sdk_result result) {
    for (size_t i = 0; i < SDK_REQUESTS; i++)
        if (c->requests[i].used)
            terminal(c, &c->requests[i], result, SDK_ESTATE, NULL, 0);
}
static void drop_data(struct sdk_core *c) {
    c->stats.data_dropped += c->count;
    c->count = 0;
    c->head = 0;
    c->stats.data_queued = 0;
    c->stats.data_bytes = 0;
}
int core_init(struct sdk_core *c, const struct sdk_config *cfg, core_sink sink, void *ctx) {
    if (!c || !cfg || !sink || !cfg->instance || !cfg->request_limit ||
        cfg->request_limit > SDK_REQUESTS || !cfg->data_items || cfg->data_items > SDK_DATA_ITEMS ||
        !cfg->data_bytes || cfg->data_bytes > SDK_DATA_BYTES)
        return SDK_EINVAL;
    memset(c, 0, sizeof(*c));
    c->config = *cfg;
    c->generation = 1;
    c->state = SDK_STARTING;
    c->sink = sink;
    c->context = ctx;
    return SDK_OK;
}
int core_invariant(const struct sdk_core *c) {
    uint64_t live = 0, bytes = 0;
    for (size_t i = 0; i < SDK_REQUESTS; i++)
        live += (unsigned)c->requests[i].used;
    for (size_t i = 0; i < c->count; i++)
        bytes += c->data[(c->head + i) % SDK_DATA_ITEMS].length;
    return live == c->stats.live && live <= c->config.request_limit &&
           c->stats.accepted == c->stats.completed + c->stats.timed_out + c->stats.cancelled +
                                    c->stats.failed + live &&
           c->count <= c->config.data_items && bytes <= c->config.data_bytes &&
           bytes == c->stats.data_bytes && c->stats.data_queued == c->count &&
           c->stats.data_arrived == c->stats.data_dropped + c->stats.data_delivered + c->count;
}
int core_event(struct sdk_core *c, const struct core_event *e) {
    if (!c || !e)
        return SDK_EINVAL;
    switch (e->type) {
    case C_READY:
        if (c->state != SDK_STARTING)
            return SDK_ESTATE;
        state(c, SDK_READY);
        break;
    case C_SUBMIT: {
        struct sdk_notice n;
        memset(&n, 0, sizeof(n));
        n.key = e->key;
        c->stats.queued++;
        int err = SDK_OK;
        if (c->state != SDK_READY)
            err = SDK_ESTATE;
        else if (e->key.instance != c->config.instance || e->key.generation != c->generation ||
                 !e->key.id || e->length > SDK_CONTROL_MAX)
            err = SDK_EINVAL;
        else if (c->stats.live >= c->config.request_limit)
            err = SDK_EFULL;
        for (size_t i = 0; i < SDK_REQUESTS; i++)
            if (c->requests[i].used && key_eq(c->requests[i].key, e->key))
                err = SDK_EINVAL;
        for (size_t i = 0; i < SDK_HISTORY; i++)
            if (c->history[i].valid && key_eq(c->history[i].key, e->key))
                err = SDK_EINVAL;
        if (err) {
            n.type = SDK_REJECT;
            n.status = err;
            c->stats.rejected++;
            notice(c, n);
            break;
        }
        struct core_request *r = NULL;
        for (size_t i = 0; i < SDK_REQUESTS; i++)
            if (!c->requests[i].used) {
                r = &c->requests[i];
                break;
            }
        if (!r)
            return SDK_EFULL;
        r->used = 1;
        r->key = e->key;
        r->deadline = e->deadline;
        r->length = e->length;
        memcpy(r->payload, e->payload, e->length);
        c->stats.accepted++;
        c->stats.live++;
        if (c->stats.live > c->stats.peak_live)
            c->stats.peak_live = c->stats.live;
        n.type = SDK_ACCEPT;
        notice(c, n);
        if (e->now >= r->deadline) {
            terminal(c, r, SDK_TIMED_OUT, SDK_ETIME, NULL, 0);
            break;
        }
        struct core_action a;
        memset(&a, 0, sizeof(a));
        a.type = A_SEND;
        a.key = r->key;
        a.flags = e->flags;
        a.deadline = r->deadline;
        a.payload = r->payload;
        a.length = r->length;
        c->sink(c->context, &a);
        break;
    }
    case C_RESPONSE: {
        if (e->key.instance != c->config.instance) {
            c->stats.unknown++;
            break;
        }
        if (e->key.generation != c->generation) {
            c->stats.old_generation++;
            break;
        }
        if (e->length > SDK_CONTROL_MAX) {
            c->stats.malformed++;
            return SDK_EINVAL;
        }
        for (size_t i = 0; i < SDK_REQUESTS; i++)
            if (c->requests[i].used && key_eq(c->requests[i].key, e->key)) {
                struct core_request *r = &c->requests[i];
                if (e->now >= r->deadline)
                    terminal(c, r, SDK_TIMED_OUT, SDK_ETIME, NULL, 0);
                else
                    terminal(c, r, e->status ? SDK_FAILED_RESULT : SDK_COMPLETED, e->status,
                             e->payload, e->length);
                return SDK_OK;
            }
        for (size_t i = 0; i < SDK_HISTORY; i++)
            if (c->history[i].valid && key_eq(c->history[i].key, e->key)) {
                if (c->history[i].result == SDK_COMPLETED)
                    c->stats.duplicates++;
                else
                    c->stats.late++;
                return SDK_OK;
            }
        c->stats.unknown++;
        break;
    }
    case C_CANCEL:
        for (size_t i = 0; i < SDK_REQUESTS; i++)
            if (c->requests[i].used && key_eq(c->requests[i].key, e->key)) {
                terminal(c, &c->requests[i], SDK_CANCELLED, SDK_OK, NULL, 0);
                return SDK_OK;
            }
        return SDK_ENOTFOUND;
    case C_TICK:
        for (size_t i = 0; i < SDK_REQUESTS; i++)
            if (c->requests[i].used && e->now >= c->requests[i].deadline)
                terminal(c, &c->requests[i], SDK_TIMED_OUT, SDK_ETIME, NULL, 0);
        break;
    case C_STOP: {
        if (c->state == SDK_CLOSED)
            break;
        state(c, SDK_STOPPING);
        end_all(c, SDK_CANCELLED);
        drop_data(c);
        struct core_action a;
        memset(&a, 0, sizeof(a));
        a.type = A_CLOSE;
        c->sink(c->context, &a);
        state(c, SDK_CLOSED);
        break;
    }
    case C_RECOVER: {
        if (c->state == SDK_CLOSED || c->state == SDK_STOPPING)
            return SDK_ESTATE;
        end_all(c, SDK_FAILED_RESULT);
        drop_data(c);
        if (c->generation == UINT32_MAX) {
            state(c, SDK_FAILED);
            return SDK_ELIMIT;
        }
        c->generation++;
        state(c, SDK_STARTING);
        struct core_action a;
        memset(&a, 0, sizeof(a));
        a.type = A_RESET;
        a.flags = e->flags;
        c->sink(c->context, &a);
        break;
    }
    case C_DISCONNECT:
        if (c->state == SDK_CLOSED)
            return SDK_ESTATE;
        end_all(c, SDK_FAILED_RESULT);
        drop_data(c);
        state(c, SDK_FAILED);
        break;
    case C_DATA:
#if !SDK_ENABLE_DATA
        c->stats.data_arrived++;
        c->stats.data_dropped++;
        return SDK_ENOTSUP;
#endif
        if (e->key.instance != c->config.instance) {
            c->stats.unknown++;
            break;
        }
        if (e->key.generation != c->generation) {
            c->stats.old_generation++;
            break;
        }
        c->stats.data_arrived++;
        if (c->state != SDK_READY || e->length > SDK_DATA_MAX || c->count >= c->config.data_items ||
            e->length > c->config.data_bytes - c->stats.data_bytes) {
            c->stats.data_dropped++;
            break;
        }
        {
            struct core_data *d = &c->data[(c->head + c->count) % SDK_DATA_ITEMS];
            d->sequence = e->sequence;
            d->length = e->length;
            memcpy(d->payload, e->payload, e->length);
            c->count++;
            c->stats.data_queued = c->count;
            c->stats.data_bytes += e->length;
            if (c->stats.data_bytes > c->stats.peak_data_bytes)
                c->stats.peak_data_bytes = c->stats.data_bytes;
        }
        break;
    case C_CONSUME:
        if (!c->count)
            return SDK_EMPTY;
        {
            struct core_data *d = &c->data[c->head];
            struct sdk_notice n;
            memset(&n, 0, sizeof(n));
            n.type = SDK_DATA;
            n.sequence = d->sequence;
            n.payload = d->payload;
            n.length = d->length;
            c->stats.data_bytes -= d->length;
            c->count--;
            c->stats.data_queued = c->count;
            c->stats.data_delivered++;
            notice(c, n);
            c->head = (c->head + 1) % SDK_DATA_ITEMS;
        }
        break;
    case C_BACKEND_COUNTS:
        c->stats.backend_generated += e->sequence;
        c->stats.backend_dropped += e->deadline;
        break;
    case C_MALFORMED:
        c->stats.malformed++;
        break;
    default:
        return SDK_EINVAL;
    }
    return SDK_OK;
}
const char *sdk_result_name(enum sdk_result r) {
    static const char *const names[] = {"completed", "timed_out", "cancelled", "failed"};
    return (unsigned)r < 4 ? names[r] : "invalid";
}
