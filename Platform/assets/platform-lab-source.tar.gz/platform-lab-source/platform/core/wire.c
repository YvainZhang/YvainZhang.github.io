#include "sdk_wire.h"
#include <string.h>
static void put32(uint8_t *p, uint32_t x) {
    for (unsigned i = 0; i < 4; i++)
        p[i] = (uint8_t)(x >> (8 * i));
}
static uint32_t get32(const uint8_t *p) {
    uint32_t x = 0;
    for (unsigned i = 0; i < 4; i++)
        x |= (uint32_t)p[i] << (8 * i);
    return x;
}
static void put64(uint8_t *p, uint64_t x) {
    for (unsigned i = 0; i < 8; i++)
        p[i] = (uint8_t)(x >> (8 * i));
}
static uint64_t get64(const uint8_t *p) {
    uint64_t x = 0;
    for (unsigned i = 0; i < 8; i++)
        x |= (uint64_t)p[i] << (8 * i);
    return x;
}
static int valid(const struct wire_message *m) {
    return m->type >= W_HELLO && m->type <= W_CLOSE && m->length <= SDK_DATA_MAX &&
           ((m->type != W_REQUEST && m->type != W_RESPONSE) || m->length <= SDK_CONTROL_MAX);
}
int wire_encode(uint8_t *p, size_t cap, const struct wire_message *m, size_t *len) {
    if (!p || !m || !len || !valid(m) || cap < WIRE_HEADER + m->length)
        return SDK_EINVAL;
    memset(p, 0, WIRE_HEADER);
    p[0] = 'P';
    p[1] = 'S';
    p[2] = SDK_API_VERSION;
    p[3] = (uint8_t)m->type;
    put32(p + 4, (uint32_t)m->length);
    put32(p + 8, m->key.instance);
    put32(p + 12, m->key.generation);
    put64(p + 16, m->key.id);
    put32(p + 24, m->flags);
    put32(p + 28, (uint32_t)m->status);
    put64(p + 32, m->sequence);
    put64(p + 40, m->backend_dropped);
    memcpy(p + WIRE_HEADER, m->payload, m->length);
    *len = WIRE_HEADER + m->length;
    return SDK_OK;
}
int wire_decode(struct wire_message *m, const uint8_t *p, size_t len) {
    if (!m || !p || len < WIRE_HEADER || p[0] != 'P' || p[1] != 'S')
        return SDK_EINVAL;
    if (p[2] != SDK_API_VERSION)
        return SDK_EVERSION;
    uint32_t n = get32(p + 4);
    if (n > SDK_DATA_MAX || len != WIRE_HEADER + n)
        return SDK_EINVAL;
    memset(m, 0, sizeof(*m));
    m->type = (enum wire_type)p[3];
    m->length = n;
    m->key.instance = get32(p + 8);
    m->key.generation = get32(p + 12);
    m->key.id = get64(p + 16);
    m->flags = get32(p + 24);
    uint32_t status = get32(p + 28);
    m->status = status <= INT32_MAX ? (int32_t)status : -1 - (int32_t)(UINT32_MAX - status);
    m->sequence = get64(p + 32);
    m->backend_dropped = get64(p + 40);
    if (!valid(m))
        return SDK_EINVAL;
    memcpy(m->payload, p + WIRE_HEADER, n);
    return SDK_OK;
}
