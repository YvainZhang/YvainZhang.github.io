#include "sdk_core.h"
#include "sdk_wire.h"
#include <assert.h>
#include <limits.h>
#include <stdio.h>
#include <string.h>
struct record {
    unsigned accept, reject, terminal, data, send;
    enum sdk_result result;
    struct sdk_key key;
    size_t len;
    uint8_t payload[SDK_DATA_MAX];
};
static void record(void *ctx, const struct core_action *a) {
    struct record *r = ctx;
    if (a->type == A_SEND) {
        r->send++;
        return;
    }
    if (a->type != A_NOTICE)
        return;
    switch (a->notice.type) {
    case SDK_ACCEPT:
        r->accept++;
        break;
    case SDK_REJECT:
        r->reject++;
        break;
    case SDK_TERMINAL:
        r->terminal++;
        r->result = a->notice.result;
        r->key = a->notice.key;
        r->len = a->notice.length;
        if (r->len)
            memcpy(r->payload, a->notice.payload, r->len);
        break;
    case SDK_DATA:
        r->data++;
        break;
    case SDK_STATE:
        break;
    }
}
static struct sdk_config config = {1, SDK_REQUESTS, SDK_DATA_ITEMS, SDK_DATA_BYTES};
static void init(struct sdk_core *c, struct record *r) {
    memset(r, 0, sizeof(*r));
    assert(core_init(c, &config, record, r) == 0);
    struct core_event e = {.type = C_READY};
    assert(core_event(c, &e) == 0);
}
static void push(struct sdk_core *c, enum core_event_type type, uint64_t id, uint64_t now,
                 uint64_t deadline) {
    struct core_event e = {.type = type,
                           .key = {c->config.instance, c->generation, id},
                           .now = now,
                           .deadline = deadline,
                           .length = 1};
    e.payload[0] = (uint8_t)id;
    core_event(c, &e);
    assert(core_invariant(c));
}
#define VECTOR(n) printf("{\"vector\":\"%s\",\"result\":\"PASS\"}\n", n)
int run_core_vectors(void) {
    struct sdk_core c;
    struct record r;
    init(&c, &r);
    push(&c, C_SUBMIT, 1, 0, 100);
    push(&c, C_RESPONSE, 1, 99, 0);
    assert(r.terminal == 1 && r.result == SDK_COMPLETED && r.payload[0] == 1);
    VECTOR("V01");
    init(&c, &r);
    push(&c, C_SUBMIT, 1, 0, 100);
    push(&c, C_RESPONSE, 1, 100, 0);
    assert(r.result == SDK_TIMED_OUT);
    VECTOR("V02");
    init(&c, &r);
    push(&c, C_SUBMIT, 1, 0, 100);
    push(&c, C_TICK, 0, 100, 0);
    push(&c, C_RESPONSE, 1, 101, 0);
    assert(r.terminal == 1 && c.stats.late == 1);
    VECTOR("V03");
    init(&c, &r);
    push(&c, C_SUBMIT, 1, 0, 100);
    push(&c, C_RESPONSE, 1, 50, 0);
    push(&c, C_RESPONSE, 1, 60, 0);
    assert(r.terminal == 1 && c.stats.duplicates == 1);
    VECTOR("V04");
    init(&c, &r);
    push(&c, C_SUBMIT, 1, 0, 100);
    push(&c, C_CANCEL, 1, 40, 0);
    push(&c, C_RESPONSE, 1, 50, 0);
    assert(r.terminal == 1 && r.result == SDK_CANCELLED);
    VECTOR("V05");
    init(&c, &r);
    push(&c, C_SUBMIT, 1, 0, 100);
    push(&c, C_RESPONSE, 1, 40, 0);
    push(&c, C_CANCEL, 1, 50, 0);
    assert(r.terminal == 1 && r.result == SDK_COMPLETED);
    VECTOR("V06");
    init(&c, &r);
    push(&c, C_SUBMIT, 1, 0, 100);
    push(&c, C_RECOVER, 0, 30, 0);
    struct core_event old = {.type = C_RESPONSE, .key = {1, 1, 1}, .now = 40};
    assert(core_event(&c, &old) == 0);
    assert(c.stats.old_generation == 1 && r.result == SDK_FAILED_RESULT);
    VECTOR("V07");
    init(&c, &r);
    for (uint64_t i = 1; i <= 17; i++)
        push(&c, C_SUBMIT, i, 0, 100);
    assert(r.accept == 16 && r.reject == 1 && c.stats.live == 16);
    VECTOR("V08");
    /* V09 is runtime ingress rejection, tested in runtime stress. */
    init(&c, &r);
    push(&c, C_STOP, 0, 0, 0);
    push(&c, C_SUBMIT, 1, 0, 100);
    assert(r.reject == 1 && r.terminal == 0);
    VECTOR("V10");
    init(&c, &r);
    push(&c, C_SUBMIT, 1, 0, 100);
    push(&c, C_TICK, 0, 100, 0);
    push(&c, C_STOP, 0, 100, 0);
    assert(r.terminal == 1 && r.result == SDK_TIMED_OUT);
    VECTOR("V11");
    init(&c, &r);
    push(&c, C_SUBMIT, UINT64_MAX - 1, 0, 100);
    push(&c, C_RESPONSE, UINT64_MAX - 1, 1, 0);
    push(&c, C_SUBMIT, UINT64_MAX - 1, 2, 100);
    assert(r.reject == 1);
    c.generation = UINT32_MAX;
    push(&c, C_RECOVER, 0, 3, 0);
    assert(c.state == SDK_FAILED);
    VECTOR("V12");
    struct sdk_core c2;
    struct record r2;
    init(&c, &r);
    init(&c2, &r2);
    c2.config.instance = 2;
    push(&c, C_SUBMIT, 1, 0, 100);
    push(&c2, C_SUBMIT, 1, 0, 100);
    struct core_event cross = {.type = C_RESPONSE, .key = {2, 1, 1}, .now = 10};
    core_event(&c, &cross);
    assert(c.stats.live == 1 && c.stats.unknown == 1);
    push(&c2, C_RESPONSE, 1, 10, 0);
    assert(r2.terminal == 1 && r.terminal == 0);
    VECTOR("V13");
    init(&c, &r);
    for (uint64_t i = 1; i <= 16; i++)
        push(&c, C_SUBMIT, i, 0, 100);
    push(&c, C_SUBMIT, 17, 0, 100);
    assert(c.stats.peak_live == 16 && r.reject == 1);
    push(&c, C_STOP, 0, 2, 0);
    assert(r.terminal == 16 && core_invariant(&c));
    VECTOR("V14-budget");
    init(&c, &r);
    c.config.data_items = 3;
    c.config.data_bytes = 5;
    struct core_event data = {.type = C_DATA, .key = {1, 1, 0}, .length = 3, .sequence = 1};
    core_event(&c, &data);
    core_event(&c, &data);
    assert(c.stats.data_dropped == 1 && c.stats.data_bytes == 3);
    push(&c, C_CONSUME, 0, 0, 0);
    assert(c.stats.data_delivered == 1 && core_invariant(&c));
    for (unsigned i = 0; i < 100; i++) {
        data.length = 1;
        core_event(&c, &data);
        push(&c, C_CONSUME, 0, 0, 0);
    }
    data.length = SDK_DATA_MAX + 1;
    core_event(&c, &data);
    assert(core_invariant(&c));
    VECTOR("data-byte-budget-wrap");
    init(&c, &r);
    struct core_event bad = {.type = C_SUBMIT, .key = {1, 1, 1}, .length = 257, .deadline = 100};
    core_event(&c, &bad);
    assert(r.reject == 1 && r.accept == 0);
    VECTOR("length-reject");
    struct wire_message m;
    memset(&m, 0, sizeof(m));
    m.type = W_REQUEST;
    m.key = (struct sdk_key){7, 9, UINT64_MAX - 5};
    m.length = 3;
    memcpy(m.payload, "ABC", 3);
    uint8_t bytes[WIRE_MAX];
    size_t len;
    assert(wire_encode(bytes, sizeof(bytes), &m, &len) == 0);
    struct wire_message decoded;
    assert(wire_decode(&decoded, bytes, len) == 0 && decoded.key.id == m.key.id &&
           memcmp(decoded.payload, "ABC", 3) == 0);
    for (size_t i = 0; i < len; i++)
        assert(wire_decode(&decoded, bytes, i) != 0);
    bytes[2] = 99;
    assert(wire_decode(&decoded, bytes, len) == SDK_EVERSION);
    bytes[2] = 1;
    bytes[4] = 255;
    bytes[5] = 255;
    assert(wire_decode(&decoded, bytes, len) == SDK_EINVAL);
    VECTOR("wire-truncation-version-endian");
    /* Each rejection and each terminal must preserve the counters. */
    assert(core_invariant(&c));
    return 0;
}
#ifndef CORE_VECTORS_LIBRARY
int main(void) { return run_core_vectors(); }
#endif
