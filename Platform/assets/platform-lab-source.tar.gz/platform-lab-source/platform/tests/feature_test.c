#define _POSIX_C_SOURCE 200809L
#include "sdk.h"
#include <assert.h>
#include <stdio.h>
int main(int argc, char **argv) {
    assert(argc == 2);
    struct sdk *s;
    struct sdk_config c = {1, 16, 32, 32768};
    assert(sdk_create(&s, &c, argv[1], NULL, NULL) == 0);
    assert(sdk_start(s) == 0);
    assert(sdk_capabilities(s).data_max == 0);
    struct sdk_key k;
    assert(sdk_submit(s, "A", 1, 100, SDK_F_STREAM, &k) == SDK_ENOTSUP);
    sdk_destroy(s);
    puts("{\"test\":\"data-disabled-capability-rejection\",\"result\":\"PASS\"}");
    return 0;
}
