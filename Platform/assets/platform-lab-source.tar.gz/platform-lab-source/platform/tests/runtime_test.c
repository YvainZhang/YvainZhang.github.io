#define _GNU_SOURCE
#include "sdk.h"
#include <assert.h>
#include <errno.h>
#include <fcntl.h>
#include <dirent.h>
#include <pthread.h>
#include <spawn.h>
#include <stdatomic.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>
struct log {
    pthread_mutex_t mutex;
    unsigned accepted, rejected, terminal, errors, data;
    struct sdk_key seen[2048];
    size_t count;
    struct sdk *sdk;
    int callback_stop;
    atomic_int ready_context, ready_checked;
    atomic_int hold, entered, release;
};
extern char **environ;
#ifdef SDK_TEST_STARTUP
static struct {
    pthread_mutex_t mutex;
    pthread_cond_t changed;
    int enabled, owner_seen, publication_checked;
    atomic_int fail_create;
    struct log *log;
} startup = {.mutex = PTHREAD_MUTEX_INITIALIZER, .changed = PTHREAD_COND_INITIALIZER};
void sdk_linux_test_owner_started(void) {
    pthread_mutex_lock(&startup.mutex);
    if (startup.enabled) {
        startup.owner_seen = 1;
        pthread_cond_broadcast(&startup.changed);
    }
    pthread_mutex_unlock(&startup.mutex);
}
void sdk_linux_test_before_publish(void) {
    pthread_mutex_lock(&startup.mutex);
    if (startup.enabled) {
        struct timespec until;
        clock_gettime(CLOCK_REALTIME, &until);
        until.tv_sec += 2;
        while (!startup.owner_seen)
            assert(pthread_cond_timedwait(&startup.changed, &startup.mutex, &until) == 0);
        assert(!atomic_load(&startup.log->ready_checked));
        startup.publication_checked = 1;
    }
    pthread_mutex_unlock(&startup.mutex);
}
int sdk_linux_test_create_error(void) {
    return atomic_exchange(&startup.fail_create, 0) ? EAGAIN : 0;
}
#endif
static void sleep_ms(unsigned ms);
static void callback(void *ctx, const struct sdk_notice *n) {
    struct log *l = ctx;
    pthread_mutex_lock(&l->mutex);
    if (n->type == SDK_ACCEPT)
        l->accepted++;
    if (n->type == SDK_REJECT)
        l->rejected++;
    if (n->type == SDK_TERMINAL) {
        l->terminal++;
        for (size_t i = 0; i < l->count; i++)
            assert(l->seen[i].instance != n->key.instance ||
                   l->seen[i].generation != n->key.generation || l->seen[i].id != n->key.id);
        assert(l->count < 2048);
        l->seen[l->count++] = n->key;
        if (n->result == SDK_COMPLETED && n->length) {
            for (size_t i = 0; i < n->length; i++)
                if (n->payload[i] != 'A')
                    l->errors++;
        }
    }
    if (n->type == SDK_DATA) {
        l->data++;
        for (size_t i = 0; i < n->length; i++)
            assert(n->payload[i] == (uint8_t)(n->sequence & 255));
    }
    int stop = l->callback_stop && n->type == SDK_TERMINAL;
    pthread_mutex_unlock(&l->mutex);
    if (n->type == SDK_STATE && n->state == SDK_READY && atomic_load(&l->ready_context)) {
        assert(sdk_stop(l->sdk) == SDK_ECONTEXT);
        assert(sdk_stop_wait(l->sdk, 10) == SDK_ECONTEXT);
        assert(sdk_destroy(l->sdk) == SDK_ECONTEXT);
        atomic_store(&l->ready_checked, 1);
    }
    if (n->type == SDK_ACCEPT && atomic_load(&l->hold)) {
        atomic_store(&l->entered, 1);
        for (unsigned i = 0; i < 1000 && !atomic_load(&l->release); i++)
            sleep_ms(1);
        assert(atomic_load(&l->release));
    }
    if (stop) {
        assert(sdk_stop(l->sdk) == SDK_ECONTEXT);
        assert(sdk_post_stop(l->sdk) == SDK_OK);
    }
}
static void sleep_ms(unsigned ms) {
    struct timespec t = {ms / 1000, (long)(ms % 1000) * 1000000};
    nanosleep(&t, NULL);
}
static int fd_count(void) {
    DIR *d = opendir("/proc/self/fd");
    assert(d);
    int n = 0;
    while (readdir(d))
        n++;
    closedir(d);
    return n;
}
static void init_log(struct log *l) {
    memset(l, 0, sizeof(*l));
    assert(pthread_mutex_init(&l->mutex, NULL) == 0);
}
static struct sdk *create(const char *sim, struct log *l, unsigned instance) {
    struct sdk *s;
    struct sdk_config c = {instance, 16, 3, 64};
    assert(sdk_create(&s, &c, sim, callback, l) == 0);
    l->sdk = s;
    assert(sdk_start(s) == 0);
    return s;
}
static struct sdk_stats wait_terminal(struct sdk *s, uint64_t terminal) {
    struct sdk_stats st;
    for (unsigned i = 0; i < 2000; i++) {
        sdk_snapshot(s, &st, NULL);
        if (st.completed + st.timed_out + st.cancelled + st.failed >= terminal)
            return st;
        sleep_ms(1);
    }
    assert(!"terminal deadline");
    return st;
}
static void invariant(struct sdk_stats s) {
    assert(s.accepted == s.completed + s.timed_out + s.cancelled + s.failed + s.live);
    assert(s.data_arrived == s.data_dropped + s.data_delivered + s.data_queued);
}
struct producer {
    struct sdk *s;
    atomic_uint *queued, *refused;
};
static void *produce(void *arg) {
    struct producer *p = arg;
    for (unsigned i = 0; i < 300; i++) {
        struct sdk_key k;
        int r = sdk_submit(p->s, "A", 1, 100, SDK_F_DROP, &k);
        if (r == SDK_QUEUED)
            atomic_fetch_add(p->queued, 1);
        else {
            assert(r == SDK_EFULL || r == SDK_ESTATE);
            atomic_fetch_add(p->refused, 1);
        }
    }
    return NULL;
}
#define PASS(n) printf("{\"runtime\":\"linux\",\"test\":\"%s\",\"result\":\"PASS\"}\n", n)
int main(int argc, char **argv) {
    if (argc == 3 && !strcmp(argv[1], "--fd-probe")) {
        int flags = fcntl(atoi(argv[2]), F_GETFD);
        return flags >= 0 && !(flags & FD_CLOEXEC) ? 0 : 2;
    }
    assert(argc == 2);
    int baseline = fd_count();
    struct log l;
    init_log(&l);
    struct sdk *s = create(argv[1], &l, 1);
    struct sdk_key k;
    char p[256];
    memset(p, 'A', sizeof(p));
    assert(sdk_submit(s, p, sizeof(p), 1000, 0, &k) == SDK_QUEUED);
    memset(p, 'B', sizeof(p));
    struct sdk_stats st = wait_terminal(s, 1);
    assert(st.completed == 1 && l.errors == 0);
    PASS("copy-lifetime");
    assert(sdk_submit(s, "A", 1, 20, SDK_F_DROP, &k) == SDK_QUEUED);
    st = wait_terminal(s, 2);
    assert(st.timed_out == 1);
    PASS("timeout");
    assert(sdk_submit(s, "A", 1, 1000, SDK_F_DELAY, &k) == SDK_QUEUED);
    assert(sdk_cancel(s, k) == SDK_QUEUED);
    st = wait_terminal(s, 3);
    assert(st.cancelled == 1);
    PASS("cancel");
    assert(sdk_submit(s, "A", 1, 500, SDK_F_DUP, &k) == SDK_QUEUED);
    wait_terminal(s, 4);
    for (unsigned i = 0; i < 500; i++) {
        sdk_snapshot(s, &st, NULL);
        if (st.duplicates)
            break;
        sleep_ms(1);
    }
    assert(st.duplicates == 1);
    PASS("duplicate");
    assert(sdk_submit(s, "A", 1, 30, SDK_F_BAD_VERSION, &k) == SDK_QUEUED);
    st = wait_terminal(s, 5);
    assert(st.malformed == 1 && st.timed_out == 2);
    PASS("protocol-version");
    assert(sdk_submit(s, "A", 1, 500, SDK_F_STREAM, &k) == SDK_QUEUED);
    st = wait_terminal(s, 6);
    assert(st.data_arrived > 0 && st.data_dropped > 0);
    invariant(st);
    PASS("data-overload");
    assert(sdk_submit(s, "A", 1, 1000, SDK_F_DROP, &k) == SDK_QUEUED);
    for (unsigned i = 0; i < 500; i++) {
        sdk_snapshot(s, &st, NULL);
        if (st.live)
            break;
        sleep_ms(1);
    }
    assert(st.live == 1);
    assert(sdk_recover(s, 0) == SDK_QUEUED);
    enum sdk_state state;
    for (unsigned i = 0; i < 1000; i++) {
        sdk_snapshot(s, &st, &state);
        if (st.failed >= 1 && state == SDK_READY)
            break;
        sleep_ms(1);
    }
    assert(state == SDK_READY && st.failed >= 1);
    assert(sdk_submit(s, "A", 1, 500, 0, &k) == SDK_QUEUED);
    assert(k.generation == 2);
    wait_terminal(s, 8);
    PASS("recover");
    struct log l2;
    init_log(&l2);
    struct sdk *s2 = create(argv[1], &l2, 2);
    assert(sdk_submit(s, "A", 1, 1000, SDK_F_DISCONNECT, &k) == SDK_QUEUED);
    st = wait_terminal(s, 9);
    sdk_snapshot(s, &st, &state);
    assert(state == SDK_FAILED);
    assert(sdk_submit(s2, "A", 1, 500, 0, &k) == SDK_QUEUED);
    assert(wait_terminal(s2, 1).completed == 1);
    PASS("multi-instance-disconnect");
    assert(sdk_recover(s, 1) == SDK_QUEUED);
    sleep_ms(10);
    sdk_snapshot(s, &st, &state);
    assert(state == SDK_FAILED);
    PASS("recover-failure");
    sdk_stop(s);
    sdk_snapshot(s, &st, &state);
    invariant(st);
    assert(state == SDK_CLOSED && st.live == 0);
    assert(sdk_submit(s, "A", 1, 100, 0, &k) == SDK_ESTATE);
    assert(sdk_stop(s) == 0);
    sdk_destroy(s);
    pthread_mutex_destroy(&l.mutex);
    sdk_destroy(s2);
    pthread_mutex_destroy(&l2.mutex);
    assert(fd_count() == baseline);
    PASS("cleanup-baseline");
    for (unsigned round = 0; round < 8; round++) {
        init_log(&l);
        s = create(argv[1], &l, round + 10);
        atomic_uint queued = 0, refused = 0;
        struct producer pr = {s, &queued, &refused};
        pthread_t threads[4];
        for (unsigned i = 0; i < 4; i++)
            assert(pthread_create(&threads[i], NULL, produce, &pr) == 0);
        if (round & 1)
            sdk_post_stop(s);
        for (unsigned i = 0; i < 4; i++)
            pthread_join(threads[i], NULL);
        sdk_stop(s);
        sdk_snapshot(s, &st, &state);
        invariant(st);
        assert(st.live == 0 && st.queued == atomic_load(&queued));
        assert(st.queued == st.accepted + st.rejected);
        assert(l.terminal == st.accepted && l.accepted == st.accepted && l.rejected == st.rejected);
        assert(atomic_load(&queued) + atomic_load(&refused) == 1200);
        sdk_destroy(s);
        pthread_mutex_destroy(&l.mutex);
        assert(fd_count() == baseline);
    }
    PASS("submit-stop-ingress-budget");
    init_log(&l);
    s = create(argv[1], &l, 30);
    l.callback_stop = 1;
    assert(sdk_submit(s, "A", 1, 500, 0, &k) == SDK_QUEUED);
    wait_terminal(s, 1);
    sdk_stop(s);
    sdk_destroy(s);
    pthread_mutex_destroy(&l.mutex);
    assert(fd_count() == baseline);
    PASS("callback-post-stop");
    struct sdk *bad;
    struct sdk_config cfg = {1, 17, 32, 32768};
    assert(sdk_create(&bad, &cfg, argv[1], NULL, NULL) == SDK_EINVAL);
    cfg.request_limit = 16;
    assert(sdk_create(&bad, &cfg, "/not/a/simulator", NULL, NULL) == SDK_OK);
    assert(sdk_start(bad) == SDK_EIO);
    sdk_destroy(bad);
    assert(fd_count() == baseline);
    PASS("create-start-rollback");
    init_log(&l);
    s = create(argv[1], &l, 40);
    atomic_store(&l.hold, 1);
    assert(sdk_submit(s, "A", 1, 2000, SDK_F_DROP, &k) == SDK_QUEUED);
    for (unsigned i = 0; i < 1000 && !atomic_load(&l.entered); i++)
        sleep_ms(1);
    assert(atomic_load(&l.entered));
    for (unsigned i = 0; i < SDK_INGRESS; i++)
        assert(sdk_submit(s, "A", 1, 2000, SDK_F_DROP, &k) == SDK_QUEUED);
    assert(sdk_submit(s, "A", 1, 2000, 0, &k) == SDK_EFULL);
    assert(sdk_stop_wait(s, 5) == SDK_ETIME);
    atomic_store(&l.release, 1);
    assert(sdk_stop_wait(s, 2000) == SDK_OK);
    sdk_snapshot(s, &st, &state);
    invariant(st);
    assert(st.queued == 65 && st.accepted == 1 && st.rejected == 64 && st.live == 0);
    sdk_destroy(s);
    pthread_mutex_destroy(&l.mutex);
    assert(fd_count() == baseline);
    PASS("V09-ingress-full-stop-timeout-cleanup");
    init_log(&l);
    atomic_store(&l.ready_context, 1);
#ifdef SDK_TEST_STARTUP
    pthread_mutex_lock(&startup.mutex);
    startup.enabled = 1;
    startup.log = &l;
    pthread_mutex_unlock(&startup.mutex);
#endif
    s = create(argv[1], &l, 42);
    assert(atomic_load(&l.ready_checked));
#ifdef SDK_TEST_STARTUP
    pthread_mutex_lock(&startup.mutex);
    assert(startup.owner_seen && startup.publication_checked);
    startup.enabled = 0;
    pthread_mutex_unlock(&startup.mutex);
#endif
    assert(sdk_destroy(s) == SDK_OK);
    pthread_mutex_destroy(&l.mutex);
    assert(fd_count() == baseline);
    PASS("ready-callback-owner-context");
#ifdef SDK_TEST_STARTUP
    cfg = (struct sdk_config){43, 16, 3, 64};
    assert(sdk_create(&bad, &cfg, argv[1], NULL, NULL) == SDK_OK);
    atomic_store(&startup.fail_create, 1);
    assert(sdk_start(bad) == SDK_EIO);
    assert(fd_count() == baseline);
    /* Rollback permits retry while no owner was created. */
    assert(sdk_start(bad) == SDK_OK);
    assert(sdk_destroy(bad) == SDK_OK);
    assert(fd_count() == baseline);
    PASS("thread-create-failure-rollback-retry");
#endif
    /* Compare the special spawn action with direct dup2 on the same fd. */
    int source = open("/dev/null", O_RDONLY | O_CLOEXEC);
    assert(source >= 0);
    int inherited = fcntl(source, F_DUPFD_CLOEXEC, 198);
    assert(inherited >= 198);
    assert(dup2(inherited, inherited) == inherited);
    assert(fcntl(inherited, F_GETFD) & FD_CLOEXEC);
    posix_spawn_file_actions_t actions;
    assert(posix_spawn_file_actions_init(&actions) == 0);
    assert(posix_spawn_file_actions_adddup2(&actions, inherited, inherited) == 0);
    char number[32];
    assert(snprintf(number, sizeof(number), "%d", inherited) > 0);
    char *probe[] = {argv[0], "--fd-probe", number, NULL};
    pid_t child;
    assert(posix_spawn(&child, argv[0], &actions, NULL, probe, environ) == 0);
    assert(posix_spawn_file_actions_destroy(&actions) == 0);
    int status;
    assert(waitpid(child, &status, 0) == child && WIFEXITED(status) && WEXITSTATUS(status) == 0);
    assert(fcntl(inherited, F_GETFD) & FD_CLOEXEC);
    close(inherited);
    close(source);
    assert(fd_count() == baseline);
    PASS("dup2-vs-spawn-same-fd-CLOEXEC");
    /* Exercise the current fixed-fd backend without inferring a prior failure. */
    int held[256];
    unsigned held_count = 0;
    do {
        assert(held_count < 256);
        held[held_count] = open("/dev/null", O_RDONLY | O_CLOEXEC);
        assert(held[held_count] >= 0 && held[held_count] <= 193);
    } while (held[held_count++] != 193);
    init_log(&l);
    s = create(argv[1], &l, 41);
    assert(sdk_submit(s, "A", 1, 500, 0, &k) == SDK_QUEUED);
    assert(wait_terminal(s, 1).completed == 1);
    sdk_destroy(s);
    pthread_mutex_destroy(&l.mutex);
    for (unsigned i = 0; i < held_count; i++)
        close(held[i]);
    assert(fd_count() == baseline);
    PASS("spawn-child-fd-collision-roundtrip");
    return 0;
}
