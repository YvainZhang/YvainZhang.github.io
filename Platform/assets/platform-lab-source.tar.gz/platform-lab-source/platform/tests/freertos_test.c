#include "FreeRTOS.h"
#include "event_groups.h"
#include "queue.h"
#include "sdk.h"
#include "semphr.h"
#include "task.h"
#include <assert.h>
#include <stdatomic.h>
#include <stdio.h>
#include <string.h>
int run_core_vectors(void);
static StaticTask_t idle_tcb, timer_tcb;
static StackType_t idle_stack[configMINIMAL_STACK_SIZE], timer_stack[configTIMER_TASK_STACK_DEPTH];
void vApplicationGetIdleTaskMemory(StaticTask_t **t, StackType_t **s, configSTACK_DEPTH_TYPE *n) {
    *t = &idle_tcb;
    *s = idle_stack;
    *n = configMINIMAL_STACK_SIZE;
}
void vApplicationGetTimerTaskMemory(StaticTask_t **t, StackType_t **s, configSTACK_DEPTH_TYPE *n) {
    *t = &timer_tcb;
    *s = timer_stack;
    *n = configTIMER_TASK_STACK_DEPTH;
}
struct log {
    unsigned terminal, bad, accept, reject;
    atomic_int hold, entered, release;
};
static void cb(void *ctx, const struct sdk_notice *n) {
    struct log *l = ctx;
    if (n->type == SDK_ACCEPT) {
        l->accept++;
        if (atomic_load(&l->hold)) {
            atomic_store(&l->entered, 1);
            for (unsigned i = 0; i < 1000 && !atomic_load(&l->release); i++)
                vTaskDelay(1);
            assert(atomic_load(&l->release));
        }
    }
    if (n->type == SDK_REJECT)
        l->reject++;
    if (n->type == SDK_TERMINAL) {
        l->terminal++;
        if (n->result == SDK_COMPLETED && n->length && n->payload[0] != 'A')
            l->bad++;
    }
}
static struct sdk_stats wait_count(struct sdk *s, uint64_t n) {
    struct sdk_stats st;
    for (unsigned i = 0; i < 3000; i++) {
        sdk_snapshot(s, &st, NULL);
        if (st.completed + st.timed_out + st.cancelled + st.failed >= n)
            return st;
        vTaskDelay(1);
    }
    assert(!"FreeRTOS deadline");
    return st;
}
#define PASS(n) printf("{\"runtime\":\"freertos\",\"test\":\"%s\",\"result\":\"PASS\"}\n", n)

struct pi_case {
    SemaphoreHandle_t mutex, entered;
    EventGroupHandle_t done;
    TaskHandle_t low;
    UBaseType_t inherited, restored;
};
static void low_owner(void *arg) {
    struct pi_case *p = arg;
    assert(xSemaphoreTake(p->mutex, portMAX_DELAY) == pdTRUE);
    xSemaphoreGive(p->entered);
    ulTaskNotifyTake(pdTRUE, portMAX_DELAY);
    p->inherited = uxTaskPriorityGet(NULL);
    assert(xSemaphoreGive(p->mutex) == pdTRUE);
    p->restored = uxTaskPriorityGet(NULL);
    xEventGroupSetBits(p->done, 1);
    vTaskDelete(NULL);
}
static void high_waiter(void *arg) {
    struct pi_case *p = arg;
    assert(xSemaphoreTake(p->mutex, portMAX_DELAY) == pdTRUE);
    xSemaphoreGive(p->mutex);
    xEventGroupSetBits(p->done, 2);
    vTaskDelete(NULL);
}
static void primitive_tests(void) {
    struct pi_case p = {0};
    p.mutex = xSemaphoreCreateMutex();
    p.entered = xSemaphoreCreateBinary();
    p.done = xEventGroupCreate();
    assert(p.mutex && p.entered && p.done);
    assert(xTaskCreate(low_owner, "pi-low", 4096, &p, 1, &p.low) == pdPASS);
    assert(xSemaphoreTake(p.entered, pdMS_TO_TICKS(1000)) == pdTRUE);
    assert(xTaskCreate(high_waiter, "pi-high", 4096, &p, 4, NULL) == pdPASS);
    assert(uxTaskPriorityGet(p.low) == 4);
    xTaskNotifyGive(p.low);
    assert((xEventGroupWaitBits(p.done, 3, pdTRUE, pdTRUE, pdMS_TO_TICKS(1000)) & 3) == 3);
    assert(p.inherited == 4 && p.restored == 1);
    xEventGroupSetBits(p.done, 3);
    assert((xEventGroupWaitBits(p.done, 3, pdTRUE, pdTRUE, 0) & 3) == 3);
    assert(xEventGroupGetBits(p.done) == 0);
    xTaskNotifyGive(xTaskGetCurrentTaskHandle());
    xTaskNotifyGive(xTaskGetCurrentTaskHandle());
    assert(ulTaskNotifyTake(pdTRUE, 0) == 2);
    vSemaphoreDelete(p.mutex);
    vSemaphoreDelete(p.entered);
    vEventGroupDelete(p.done);
    puts("{\"runtime\":\"freertos\",\"test\":\"mutex-PI-event-bits-notification-count\",\"result\":"
         "\"PASS\"}");
}
static void suite(void *unused) {
    (void)unused;
    assert(run_core_vectors() == 0);
    struct sdk_config cfg = {1, 16, 3, 64};
    struct sdk *a, *b;
    struct log la = {0}, lb = {0};
    assert(sdk_create(&a, &cfg, NULL, cb, &la) == 0);
    assert(sdk_start(a) == 0);
    cfg.instance = 2;
    assert(sdk_create(&b, &cfg, NULL, cb, &lb) == 0);
    assert(sdk_start(b) == 0);
    struct sdk_key k;
    char payload[2] = "A";
    assert(sdk_submit(a, payload, 1, 500, 0, &k) == SDK_QUEUED);
    payload[0] = 'B';
    struct sdk_stats st = wait_count(a, 1);
    assert(st.completed == 1 && la.bad == 0);
    PASS("copy-lifetime");
    assert(sdk_submit(a, "A", 1, 20, SDK_F_DROP, &k) == SDK_QUEUED);
    st = wait_count(a, 2);
    assert(st.timed_out == 1);
    PASS("timeout");
    assert(sdk_submit(a, "A", 1, 500, SDK_F_DELAY, &k) == SDK_QUEUED);
    assert(sdk_cancel(a, k) == SDK_QUEUED);
    st = wait_count(a, 3);
    assert(st.cancelled == 1);
    PASS("cancel");
    assert(sdk_submit(a, "A", 1, 500, SDK_F_DUP, &k) == SDK_QUEUED);
    wait_count(a, 4);
    for (unsigned i = 0; i < 500; i++) {
        sdk_snapshot(a, &st, NULL);
        if (st.duplicates)
            break;
        vTaskDelay(1);
    }
    assert(st.duplicates == 1);
    PASS("duplicate");
    assert(sdk_submit(a, "A", 1, 500, SDK_F_STREAM, &k) == SDK_QUEUED);
    st = wait_count(a, 5);
    assert(st.data_arrived > 0 && st.data_dropped > 0);
    assert(st.data_arrived == st.data_delivered + st.data_dropped + st.data_queued);
    PASS("data-overload");
    assert(sdk_submit(a, "A", 1, 500, SDK_F_DROP, &k) == SDK_QUEUED);
    for (unsigned i = 0; i < 100; i++) {
        sdk_snapshot(a, &st, NULL);
        if (st.live)
            break;
        vTaskDelay(1);
    }
    assert(st.live == 1);
    assert(sdk_recover(a, 0) == SDK_QUEUED);
    wait_count(a, 6);
    for (unsigned i = 0; i < 100; i++) {
        enum sdk_state state;
        sdk_snapshot(a, NULL, &state);
        if (state == SDK_READY)
            break;
        vTaskDelay(1);
    }
    assert(sdk_submit(a, "A", 1, 500, 0, &k) == SDK_QUEUED);
    assert(k.generation == 2);
    wait_count(a, 7);
    PASS("recover");
    assert(sdk_submit(a, "A", 1, 500, SDK_F_DISCONNECT, &k) == SDK_QUEUED);
    st = wait_count(a, 8);
    assert(st.failed == 2);
    assert(sdk_submit(b, "A", 1, 500, 0, &k) == SDK_QUEUED);
    assert(wait_count(b, 1).completed == 1);
    PASS("multi-instance-disconnect");
    assert(sdk_recover(a, 1) == SDK_QUEUED);
    vTaskDelay(5);
    enum sdk_state state;
    sdk_snapshot(a, NULL, &state);
    assert(state == SDK_FAILED);
    PASS("recover-failure");
    sdk_stop(a);
    sdk_snapshot(a, &st, &state);
    assert(st.live == 0 && state == SDK_CLOSED &&
           st.accepted == st.completed + st.timed_out + st.cancelled + st.failed);
    assert(sdk_submit(a, "A", 1, 100, 0, &k) == SDK_ESTATE);
    assert(la.terminal == st.accepted);
    sdk_destroy(a);
    sdk_destroy(b);
    PASS("cleanup-conservation");
    struct log gate = {0};
    cfg.instance = 3;
    assert(sdk_create(&a, &cfg, NULL, cb, &gate) == SDK_OK);
    assert(sdk_start(a) == SDK_OK);
    atomic_store(&gate.hold, 1);
    assert(sdk_submit(a, "A", 1, 2000, SDK_F_DROP, &k) == SDK_QUEUED);
    for (unsigned i = 0; i < 1000 && !atomic_load(&gate.entered); i++)
        vTaskDelay(1);
    assert(atomic_load(&gate.entered));
    for (unsigned i = 0; i < SDK_INGRESS; i++)
        assert(sdk_submit(a, "A", 1, 2000, SDK_F_DROP, &k) == SDK_QUEUED);
    assert(sdk_submit(a, "A", 1, 2000, 0, &k) == SDK_EFULL);
    assert(sdk_stop_wait(a, 5) == SDK_ETIME);
    atomic_store(&gate.release, 1);
    assert(sdk_stop_wait(a, 2000) == SDK_OK);
    sdk_snapshot(a, &st, &state);
    assert(st.queued == 65 && st.accepted == 1 && st.rejected == 64 && st.live == 0);
    sdk_destroy(a);
    PASS("V09-ingress-full-stop-timeout-cleanup");
    vTaskDelay(5);
    /* queue copy, notification coalescing, predicate independent of wake count */
    QueueHandle_t q = xQueueCreate(1, sizeof(int));
    int value = 42;
    assert(xQueueSend(q, &value, 0) == pdTRUE);
    value = 7;
    assert(xQueueSend(q, &value, 0) == errQUEUE_FULL);
    assert(xQueueReceive(q, &value, 0) == pdTRUE && value == 42);
    vQueueDelete(q);
    PASS("queue-copy-full");
    primitive_tests();
    vTaskDelay(5);
    printf("{\"freertos\":\"V11.1.0 "
           "POSIX\",\"heap_free\":%zu,\"stack_words\":%lu,\"result\":\"PASS\"}\n",
           xPortGetFreeHeapSize(), (unsigned long)uxTaskGetStackHighWaterMark(NULL));
    fflush(stdout);
    vTaskEndScheduler();
    vTaskDelete(NULL);
}
int main(void) {
    setvbuf(stdout, NULL, _IONBF, 0);
    assert(xTaskCreate(suite, "contract-tests", 16384, NULL, 1, NULL) == pdPASS);
    vTaskStartScheduler();
    return 0;
}
