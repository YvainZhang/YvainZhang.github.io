#include "sdk.h"
#include <assert.h>
#include <stdio.h>
int main(int argc, char **argv) {
    assert(argc == 2);
    struct sdk *s;
    struct sdk_config c = {1, 16, 32, 32768};
    assert(sdk_create(&s, &c, argv[1], NULL, NULL) == 0);
    assert(sdk_start(s) == 0);
    struct sdk_budget b = sdk_resource_budget(s);
    printf("core_bytes=%zu runtime_bytes=%zu owner_stack_bytes=%zu backend_stack_bytes=%zu\n",
           b.core_bytes, b.runtime_bytes, b.owner_stack_bytes, b.backend_stack_bytes);
    assert(sdk_stop_wait(s, 2000) == 0);
    assert(sdk_destroy(s) == 0);
    return 0;
}
