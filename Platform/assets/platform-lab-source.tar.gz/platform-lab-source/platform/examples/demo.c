#define _POSIX_C_SOURCE 200809L
#include "sdk.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
static void notice(void *ctx, const struct sdk_notice *n) {
    (void)ctx;
    if (n->type == SDK_TERMINAL)
        printf("request=%llu result=%s payload=%.*s\n", (unsigned long long)n->key.id,
               sdk_result_name(n->result), (int)n->length,
               n->payload ? (const char *)n->payload : "");
    else if (n->type == SDK_REJECT)
        printf("request=%llu rejected=%d\n", (unsigned long long)n->key.id, n->status);
}
int main(int argc, char **argv) {
    if (argc != 2) {
        fprintf(stderr, "usage: %s /absolute/path/device-sim\n", argv[0]);
        return 2;
    }
    struct sdk *s;
    struct sdk_config c = {1, 16, 32, 32768};
    if (sdk_create(&s, &c, argv[1], notice, NULL) || sdk_start(s))
        return 1;
    struct sdk_key ticket;
    int r = sdk_submit(s, "hello", 5, 100, 0, &ticket);
    if (r != SDK_QUEUED)
        return 1;
    struct timespec pause = {0, 20000000};
    struct sdk_stats stats;
    for (unsigned i = 0; i < 100; i++) {
        sdk_snapshot(s, &stats, NULL);
        if (stats.completed)
            break;
        nanosleep(&pause, NULL);
    }
    sdk_stop(s);
    sdk_snapshot(s, &stats, NULL);
    printf("accepted=%llu completed=%llu live=%llu\n", (unsigned long long)stats.accepted,
           (unsigned long long)stats.completed, (unsigned long long)stats.live);
    int ok = stats.completed == 1 && stats.live == 0;
    sdk_destroy(s);
    return ok ? 0 : 1;
}
