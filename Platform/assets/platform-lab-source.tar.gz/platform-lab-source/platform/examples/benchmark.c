#define _GNU_SOURCE
#include "sdk.h"
#include <assert.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#define SAMPLES 10000
struct measurement {
    pthread_mutex_t mutex;
    pthread_cond_t changed;
    unsigned queued, terminal, rejected, bad;
    uint64_t begin[SAMPLES + 1], latency[SAMPLES + 1];
    enum sdk_result result[SAMPLES + 1];
};
static uint64_t ns(void) {
    struct timespec t;
    clock_gettime(CLOCK_MONOTONIC, &t);
    return (uint64_t)t.tv_sec * 1000000000 + (uint64_t)t.tv_nsec;
}
static void cb(void *ctx, const struct sdk_notice *n) {
    struct measurement *m = ctx;
    pthread_mutex_lock(&m->mutex);
    if (n->type == SDK_REJECT) {
        m->rejected++;
        pthread_cond_signal(&m->changed);
    }
    if (n->type == SDK_TERMINAL) {
        assert(n->key.id <= SAMPLES);
        m->terminal++;
        m->latency[n->key.id] = ns() - m->begin[n->key.id];
        m->result[n->key.id] = n->result;
        if (n->result == SDK_COMPLETED) {
            assert(n->length == 256);
            for (size_t i = 0; i < n->length; i++)
                if (n->payload[i] != 'A')
                    m->bad++;
        }
        pthread_cond_signal(&m->changed);
    }
    pthread_mutex_unlock(&m->mutex);
}
int main(int argc, char **argv) {
    assert(argc == 5);
    unsigned limit = (unsigned)strtoul(argv[2], NULL, 10),
             round = (unsigned)strtoul(argv[3], NULL, 10);
    assert(limit > 0 && limit <= 16);
    struct measurement *m = calloc(1, sizeof(*m));
    assert(m);
    pthread_mutex_init(&m->mutex, NULL);
    pthread_cond_init(&m->changed, NULL);
    struct sdk *s;
    struct sdk_config cfg = {100 + round, limit, 32, 32768};
    assert(sdk_create(&s, &cfg, argv[1], cb, m) == 0 && sdk_start(s) == 0);
    uint8_t payload[256];
    memset(payload, 'A', 256);
    uint64_t started = ns();
    for (unsigned i = 1; i <= SAMPLES; i++) {
        pthread_mutex_lock(&m->mutex);
        while (m->queued - m->terminal - m->rejected >= limit)
            pthread_cond_wait(&m->changed, &m->mutex);
        struct sdk_key k;
        m->begin[i] = ns();
        assert(sdk_submit(s, payload, 256, 2000, 0, &k) == SDK_QUEUED && k.id == i);
        m->queued++;
        pthread_mutex_unlock(&m->mutex);
    }
    pthread_mutex_lock(&m->mutex);
    while (m->terminal + m->rejected < SAMPLES)
        pthread_cond_wait(&m->changed, &m->mutex);
    pthread_mutex_unlock(&m->mutex);
    uint64_t elapsed = ns() - started;
    sdk_stop(s);
    struct sdk_stats st;
    sdk_snapshot(s, &st, NULL);
    assert(st.accepted == st.completed + st.timed_out + st.cancelled + st.failed && st.live == 0 &&
           !m->bad && !m->rejected);
    FILE *f = fopen(argv[4], "w");
    assert(f);
    fprintf(f, "limit,round,id,result,latency_ns\n");
    for (unsigned i = 1; i <= SAMPLES; i++)
        fprintf(f, "%u,%u,%u,%s,%llu\n", limit, round, i, sdk_result_name(m->result[i]),
                (unsigned long long)m->latency[i]);
    fclose(f);
    printf("{\"limit\":%u,\"round\":%u,\"samples\":%u,\"completed\":%llu,\"failed\":%llu,\"elapsed_"
           "ns\":%llu,\"requests_per_s\":%.2f}\n",
           limit, round, SAMPLES, (unsigned long long)st.completed,
           (unsigned long long)(st.timed_out + st.cancelled + st.failed),
           (unsigned long long)elapsed, SAMPLES * 1e9 / (double)elapsed);
    sdk_destroy(s);
    pthread_cond_destroy(&m->changed);
    pthread_mutex_destroy(&m->mutex);
    free(m);
    return 0;
}
