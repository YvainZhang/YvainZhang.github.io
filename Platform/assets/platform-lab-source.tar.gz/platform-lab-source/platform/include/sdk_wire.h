#ifndef SDK_WIRE_H
#define SDK_WIRE_H
#include "sdk.h"
#define WIRE_HEADER 48u
#define WIRE_MAX (WIRE_HEADER + SDK_DATA_MAX)
enum wire_type { W_HELLO = 1, W_REQUEST, W_RESPONSE, W_DATA, W_CLOSE };
struct wire_message {
    enum wire_type type;
    struct sdk_key key;
    uint32_t flags;
    uint64_t sequence, backend_dropped;
    int32_t status;
    size_t length;
    uint8_t payload[SDK_DATA_MAX];
};
int wire_encode(uint8_t *, size_t, const struct wire_message *, size_t *);
int wire_decode(struct wire_message *, const uint8_t *, size_t);
#endif
