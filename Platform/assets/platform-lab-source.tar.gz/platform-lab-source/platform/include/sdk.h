#ifndef PLATFORM_SDK_H
#define PLATFORM_SDK_H
#include <stddef.h>
#include <stdint.h>
#define SDK_API_VERSION 1u
#ifndef SDK_ENABLE_DATA
#define SDK_ENABLE_DATA 1
#endif
#if SDK_ENABLE_DATA != 0 && SDK_ENABLE_DATA != 1
#error SDK_ENABLE_DATA must be 0 or 1
#endif
#define SDK_REQUESTS 16u
#define SDK_CONTROL_MAX 256u
#define SDK_DATA_MAX 1024u
#define SDK_DATA_ITEMS 32u
#define SDK_DATA_BYTES 32768u
#define SDK_INGRESS 64u
#define SDK_HISTORY 64u
#define SDK_F_DROP 1u
#define SDK_F_DUP 2u
#define SDK_F_DISCONNECT 4u
#define SDK_F_STREAM 8u
#define SDK_F_BAD_VERSION 16u
#define SDK_F_DELAY 32u
#define SDK_F_RECOVER_FAIL 64u
/* Queued is transport admission only; ACCEPT/REJECT arrives asynchronously. */
enum sdk_status {
    SDK_OK = 0,
    SDK_QUEUED = 1,
    SDK_EMPTY = 2,
    SDK_EINVAL = -1,
    SDK_EFULL = -2,
    SDK_ESTATE = -3,
    SDK_ENOTFOUND = -4,
    SDK_EIO = -5,
    SDK_EVERSION = -6,
    SDK_ECONTEXT = -7,
    SDK_ELIMIT = -8,
    SDK_ETIME = -9,
    SDK_ENOTSUP = -10
};
enum sdk_state { SDK_STARTING, SDK_READY, SDK_STOPPING, SDK_CLOSED, SDK_FAILED };
enum sdk_result { SDK_COMPLETED, SDK_TIMED_OUT, SDK_CANCELLED, SDK_FAILED_RESULT };
struct sdk_key {
    uint32_t instance, generation;
    uint64_t id;
};
struct sdk_stats {
    uint64_t queued, accepted, rejected, completed, timed_out, cancelled, failed, live, duplicates,
        late, unknown, old_generation, malformed, data_arrived, data_dropped, data_delivered,
        data_queued, data_bytes, peak_live, peak_data_bytes, backend_generated, backend_dropped;
};
struct sdk_config {
    uint32_t instance, request_limit, data_items, data_bytes;
};
struct sdk_caps {
    uint32_t api_version, control_max, data_max, request_limit;
    int remote_cancel, pause_data;
};
enum sdk_notice_type { SDK_ACCEPT, SDK_REJECT, SDK_TERMINAL, SDK_DATA, SDK_STATE };
struct sdk_notice {
    enum sdk_notice_type type;
    struct sdk_key key;
    enum sdk_result result;
    int status;
    enum sdk_state state;
    const uint8_t *payload;
    size_t length;
    uint64_t sequence;
};
typedef void (*sdk_callback)(void *, const struct sdk_notice *);
struct sdk_budget {
    size_t core_bytes, runtime_bytes, owner_stack_bytes, backend_stack_bytes;
};
struct sdk;
int sdk_create(struct sdk **, const struct sdk_config *, const char *simulator, sdk_callback,
               void *);
int sdk_start(struct sdk *);
int sdk_submit(struct sdk *, const void *, size_t, uint64_t timeout_ms, uint32_t flags,
               struct sdk_key *ticket);
int sdk_cancel(struct sdk *, struct sdk_key);
int sdk_recover(struct sdk *, int inject_failure);
int sdk_post_stop(struct sdk *);
int sdk_stop_wait(struct sdk *, uint32_t timeout_ms);
int sdk_stop(struct sdk *); /* rejected from owner callback; join externally */
int sdk_snapshot(struct sdk *, struct sdk_stats *, enum sdk_state *);
struct sdk_caps sdk_capabilities(const struct sdk *);
struct sdk_budget sdk_resource_budget(const struct sdk *);
int sdk_destroy(struct sdk *); /* caller serializes destroy with all API users */
const char *sdk_result_name(enum sdk_result);
#endif
