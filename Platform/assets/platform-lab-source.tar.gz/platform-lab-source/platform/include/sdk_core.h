#ifndef PLATFORM_SDK_CORE_H
#define PLATFORM_SDK_CORE_H
#include "sdk.h"
enum core_event_type {
    C_READY,
    C_SUBMIT,
    C_RESPONSE,
    C_CANCEL,
    C_TICK,
    C_STOP,
    C_RECOVER,
    C_DISCONNECT,
    C_DATA,
    C_CONSUME,
    C_BACKEND_COUNTS,
    C_MALFORMED
};
struct core_event {
    enum core_event_type type;
    struct sdk_key key;
    uint64_t now, deadline, sequence;
    uint32_t flags;
    int status;
    size_t length;
    uint8_t payload[SDK_DATA_MAX];
};
enum core_action_type { A_SEND, A_NOTICE, A_RESET, A_CLOSE };
struct core_action {
    enum core_action_type type;
    struct sdk_notice notice;
    struct sdk_key key;
    uint32_t flags;
    uint64_t deadline;
    const uint8_t *payload;
    size_t length;
};
typedef void (*core_sink)(void *, const struct core_action *);
struct core_request {
    int used;
    struct sdk_key key;
    uint64_t deadline;
    size_t length;
    uint8_t payload[SDK_CONTROL_MAX];
};
struct core_history {
    struct sdk_key key;
    enum sdk_result result;
    int valid;
};
struct core_data {
    uint64_t sequence;
    size_t length;
    uint8_t payload[SDK_DATA_MAX];
};
struct sdk_core {
    struct sdk_config config;
    enum sdk_state state;
    uint32_t generation;
    struct sdk_stats stats;
    struct core_request requests[SDK_REQUESTS];
    struct core_history history[SDK_HISTORY];
    size_t history_next;
    struct core_data data[SDK_DATA_ITEMS];
    size_t head, count;
    core_sink sink;
    void *context;
};
int core_init(struct sdk_core *, const struct sdk_config *, core_sink, void *);
int core_event(struct sdk_core *, const struct core_event *);
int core_invariant(const struct sdk_core *);
#endif
