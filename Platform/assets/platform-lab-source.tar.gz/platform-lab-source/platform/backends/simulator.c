#define _GNU_SOURCE
#include "sdk_wire.h"
#include <errno.h>
#include <poll.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <time.h>
#include <unistd.h>
struct scheduled {
    int used;
    uint64_t due;
    struct wire_message message;
};
static uint64_t now_ms(void) {
    struct timespec t;
    clock_gettime(CLOCK_MONOTONIC, &t);
    return (uint64_t)t.tv_sec * 1000 + (uint64_t)t.tv_nsec / 1000000;
}
static int send_message(int fd, struct wire_message *m, int bad) {
    uint8_t p[WIRE_MAX];
    size_t len;
    if (wire_encode(p, sizeof(p), m, &len) != SDK_OK)
        return -1;
    if (bad)
        p[2] = 99;
    ssize_t n = send(fd, p, len, MSG_NOSIGNAL);
    return n == (ssize_t)len ? 0 : -1;
}
int main(int argc, char **argv) {
    if (argc != 3 || strcmp(argv[1], "--fd"))
        return 2;
    int fd = atoi(argv[2]);
    struct scheduled slots[SDK_REQUESTS * 2];
    memset(slots, 0, sizeof(slots));
    struct wire_message hello;
    memset(&hello, 0, sizeof(hello));
    hello.type = W_HELLO;
    if (send_message(fd, &hello, 0))
        return 3;
    uint64_t seq = 0, dropped = 0;
    for (;;) {
        uint64_t now = now_ms();
        for (size_t i = 0; i < SDK_REQUESTS * 2; i++)
            if (slots[i].used && now >= slots[i].due) {
                if (send_message(fd, &slots[i].message,
                                 (slots[i].message.flags & SDK_F_BAD_VERSION) != 0)) {
                    if (errno == EAGAIN || errno == EWOULDBLOCK)
                        continue;
                    close(fd);
                    return 0;
                }
                if (slots[i].message.flags & SDK_F_DUP) {
                    slots[i].message.flags &= ~SDK_F_DUP;
                    slots[i].due = now + 2;
                } else
                    slots[i].used = 0;
            }
        struct pollfd pfd = {.fd = fd, .events = POLLIN};
        int r = poll(&pfd, 1, 2);
        if (r < 0) {
            if (errno == EINTR)
                continue;
            return 4;
        }
        if (!r)
            continue;
        uint8_t p[WIRE_MAX];
        ssize_t n = recv(fd, p, sizeof(p), MSG_TRUNC);
        if (n < 0 && (errno == EAGAIN || errno == EINTR))
            continue;
        if (n <= 0)
            break;
        struct wire_message m;
        if (n > (ssize_t)sizeof(p) || wire_decode(&m, p, (size_t)n))
            continue;
        if (m.type == W_CLOSE)
            break;
        if (m.type != W_REQUEST)
            continue;
        if (m.flags & SDK_F_DISCONNECT)
            break;
        if (m.flags & SDK_F_STREAM) {
            for (unsigned i = 0; i < 80; i++) {
                struct wire_message d;
                memset(&d, 0, sizeof(d));
                d.type = W_DATA;
                d.key = m.key;
                d.sequence = ++seq;
                d.length = 32;
                memset(d.payload, (int)(seq & 255), d.length);
                if (send_message(fd, &d, 0)) {
                    if (errno == EAGAIN || errno == EWOULDBLOCK)
                        dropped++;
                    else {
                        close(fd);
                        return 0;
                    }
                }
            }
        }
        if (m.flags & SDK_F_DROP)
            continue;
        for (size_t i = 0; i < SDK_REQUESTS * 2; i++)
            if (!slots[i].used) {
                slots[i].used = 1;
                slots[i].due = now_ms() + ((m.flags & SDK_F_DELAY) ? 200 : 5);
                slots[i].message = m;
                slots[i].message.sequence = seq;
                slots[i].message.backend_dropped = dropped;
                slots[i].message.type = W_RESPONSE;
                break;
            }
    }
    close(fd);
    return 0;
}
