#!/usr/bin/env python3
import csv
import json
import pathlib
import statistics
import argparse
parser=argparse.ArgumentParser()
parser.add_argument('--input', default='build/benchmark')
args=parser.parse_args()
root = pathlib.Path(__file__).resolve().parents[1]
report = []
for limit in (4, 16):
    files = sorted((root/args.input).glob(f'limit-{limit}-round-*.csv'))
    for p in files:
        rows = list(csv.DictReader(p.open()))
        assert rows, p
        values = sorted(int(r['latency_ns'])/1e6 for r in rows if r['result']=='completed')
        report.append({'limit': limit, 'round': p.stem, 'samples': len(rows),
            'failures': len(rows)-len(values), 'median_ms': statistics.median(values) if values else None,
            'p95_ms': values[int(.95*(len(values)-1))] if values else None,
            'p99_ms': values[int(.99*(len(values)-1))] if values else None})
(root/args.input/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
