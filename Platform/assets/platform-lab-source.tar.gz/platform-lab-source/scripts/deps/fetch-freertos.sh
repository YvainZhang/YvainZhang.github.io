#!/bin/sh
set -eu
version=V11.1.0
expected=0e21928b3bcc4f9bcaf7333fb1c8c0299d97e2ec9e13e3faa2c5a7ac8a3bc573
mkdir -p third_party
if [ ! -f third_party/freertos.tar.gz ]; then
 curl -fL --retry 2 --connect-timeout 20 --max-time 120 "https://github.com/FreeRTOS/FreeRTOS-Kernel/archive/refs/tags/$version.tar.gz" -o third_party/freertos.tar.gz
fi
printf '%s  %s\n' "$expected" third_party/freertos.tar.gz | sha256sum -c -
if [ ! -f third_party/FreeRTOS-Kernel/tasks.c ]; then
 tar -xzf third_party/freertos.tar.gz -C third_party
 mv "third_party/FreeRTOS-Kernel-${version#V}" third_party/FreeRTOS-Kernel
fi
printf '%s\n' "$version" > third_party/FreeRTOS-Kernel.version
sha256sum third_party/freertos.tar.gz > third_party/FreeRTOS-Kernel.archive.sha256
