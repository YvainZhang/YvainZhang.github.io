#!/usr/bin/env python3
import pathlib, re, urllib.parse
root = pathlib.Path(__file__).resolve().parents[1]
errors = []
for p in sorted(root.glob('*.md')):
    for target in re.findall(r'!?\[[^\]]*\]\(([^)]+)\)', p.read_text()):
        target = target.split('#')[0]
        if not target or urllib.parse.urlparse(target).scheme:
            continue
        if not (p.parent/urllib.parse.unquote(target)).exists():
            errors.append(f'{p.name}: {target}')
if errors:
    raise SystemExit('\n'.join(errors))
print('Public archive Markdown local targets: PASS')
