#!/usr/bin/env python3
"""Validate the controlled ABBA hang, with an exact trigger and external deadline."""
import pathlib
import subprocess
root = pathlib.Path(__file__).resolve().parents[1]
subprocess.run(['make', '-C', 'labs', 'counterexample'], cwd=root, check=True)
try:
    result = subprocess.run([str(root / 'build/labs/abba')], cwd=root,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=2)
except subprocess.TimeoutExpired as exc:
    output = exc.stdout or b''
    assert b'both first locks acquired' in output, output
    print('{"test":"ABBA-controlled-timeout","result":"PASS"}')
else:
    raise SystemExit('Expected both threads to block, got exit ' + str(result.returncode))
