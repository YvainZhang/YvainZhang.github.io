#!/bin/sh
set -eu
root=$(CDPATH= cd -- "$(dirname "$0")/.." && pwd)
suite=${1:-user}
image=platform-arch-lab:alpine3.22
case "$suite" in
 shell) exec docker run --rm -it --network none -v "$root:/work" -w /work "$image" sh ;;
 deps) exec docker run --rm -v "$root:/work" -w /work "$image" sh scripts/deps/fetch-freertos.sh ;;
 user|startup|freertos|benchmark|kernel-build|reproduction) exec docker run --rm --network none -v "$root:/work" -w /work "$image" python3 scripts/verify.py --suite "$suite" ;;
 network) exec docker run --rm --network none --cap-add NET_ADMIN --cap-add SYS_ADMIN --security-opt apparmor=unconfined -v "$root:/work" -w /work "$image" sh -c 'mkdir -p /dev/net; test -c /dev/net/tun || mknod /dev/net/tun c 10 200; python3 scripts/verify.py --suite network' ;;
 sanitize) exec docker run --rm --network none -v "$root:/work" -w /work platform-arch-sanitizers:bookworm python3 scripts/verify.py --suite sanitize ;;
 tsan) exec docker run --rm --network none --security-opt seccomp=unconfined -v "$root:/work" -w /work platform-arch-sanitizers:bookworm python3 scripts/verify.py --suite tsan ;;
 *) echo 'usage: run-container.sh shell|deps|user|startup|freertos|network|benchmark|sanitize|tsan|kernel-build|reproduction' >&2; exit 2 ;;
esac
