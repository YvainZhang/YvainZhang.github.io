#!/usr/bin/env python3
"""Prove deadline vector detects a deliberate contract regression, safely in tmp."""
import pathlib
import subprocess
import tempfile
root = pathlib.Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory(prefix='platform-mutation-') as tmp:
    path = pathlib.Path(tmp)
    source = (root/'platform/core/core.c').read_text()
    target = 'e->now >= r->deadline'
    assert target in source
    (path/'core.c').write_text(source.replace(target, 'e->now > r->deadline'))
    compiled = subprocess.run(['cc', '-std=c11', '-Wall', '-Wextra', '-Werror',
        '-I'+str(root/'platform/include'), str(path/'core.c'),
        str(root/'platform/core/wire.c'), str(root/'platform/tests/core_vectors.c'),
        '-o', str(path/'mutated')], capture_output=True, text=True)
    assert compiled.returncode == 0, compiled.stderr
    result = subprocess.run([str(path/'mutated')], capture_output=True, timeout=5)
    assert result.returncode != 0 and b'r.result == SDK_TIMED_OUT' in result.stderr, result.stderr
    print('{"test":"deadline-mutation-detected","result":"PASS"}')
