#!/bin/sh
# Run only inside a disposable Linux container or an isolated lab VM as root.
set -eu
cd "$(dirname "$0")/.."
for ns in ll-a ll-b; do
    if ip netns list | awk '{print $1}' | grep -qx "$ns"; then
        echo "existing namespace $ns; refusing to alter it" >&2
        exit 1
    fi
done
for dev in lla0 llb0; do
    if ip link show "$dev" >/dev/null 2>&1; then
        echo "existing interface $dev; refusing to alter it" >&2
        exit 1
    fi
done
pid=
capture_pid=
made_a=0
made_b=0
cleanup() {
    if [ -n "$capture_pid" ]; then kill -INT "$capture_pid" 2>/dev/null || true; wait "$capture_pid" 2>/dev/null || true; fi
    if [ -n "$pid" ]; then
        kill -TERM "$pid" 2>/dev/null || true
        wait "$pid" 2>/dev/null || true
    fi
    if [ "$made_a" = 1 ]; then ip netns del ll-a; fi
    if [ "$made_b" = 1 ]; then ip netns del ll-b; fi
}
trap cleanup EXIT
trap 'exit 130' INT
trap 'exit 143' TERM
make
ip netns add ll-a
made_a=1
ip netns add ll-b
made_b=1
: >build/smoke.log
./build/link-lab lla0 llb0 --delay-ms "${LINK_DELAY_MS:-0}" --drop-every "${LINK_DROP_EVERY:-0}" >build/smoke.log 2>&1 &
pid=$!
attempt=0
until grep -qx ready build/smoke.log; do
    if ! kill -0 "$pid" 2>/dev/null; then cat build/smoke.log; exit 1; fi
    attempt=$((attempt + 1))
    if [ "$attempt" -gt 50 ]; then echo 'startup timeout' >&2; exit 1; fi
    sleep 0.1
done
ip link set lla0 netns ll-a
ip link set llb0 netns ll-b
ip -n ll-a link set lo up
ip -n ll-b link set lo up
ip -n ll-a addr add 192.0.2.1/24 dev lla0
ip -n ll-b addr add 192.0.2.2/24 dev llb0
ip -n ll-a link set lla0 up
ip -n ll-b link set llb0 up
if [ -n "${CAPTURE_PCAP:-}" ]; then
    ip netns exec ll-a tcpdump -i lla0 -U -w "$CAPTURE_PCAP" >build/tcpdump.log 2>&1 &
    capture_pid=$!
    attempt=0
    until grep -q 'listening on' build/tcpdump.log; do
        kill -0 "$capture_pid"
        attempt=$((attempt + 1))
        if [ "$attempt" -gt 50 ]; then echo 'capture timeout' >&2; exit 1; fi
        sleep 0.1
    done
fi
ip netns exec ll-a ping -c 3 -W 2 192.0.2.2
ip netns exec ll-b ping -c 3 -W 2 192.0.2.1
kill -USR1 "$pid"
attempt=0
until grep -qx 'mode=blocked' build/smoke.log; do
    kill -0 "$pid"
    attempt=$((attempt + 1))
    if [ "$attempt" -gt 50 ]; then echo 'block timeout' >&2; exit 1; fi
    sleep 0.1
done
# Keep the same process and TAPs alive: only forwarding behavior changes.
ip -n ll-a link show lla0 >/dev/null
ip -n ll-b link show llb0 >/dev/null
set +e
ip netns exec ll-a ping -c 2 -W 1 192.0.2.2
ping_status=$?
set -e
if [ "$ping_status" -ne 1 ]; then
    echo "expected unanswered ping (exit 1), got $ping_status" >&2
    exit 1
fi
kill -USR2 "$pid"
attempt=0
until grep -qx 'mode=forwarding' build/smoke.log; do
    kill -0 "$pid"
    attempt=$((attempt + 1))
    if [ "$attempt" -gt 50 ]; then echo 'resume timeout' >&2; exit 1; fi
    sleep 0.1
done
ip netns exec ll-a ping -c 3 -W 2 192.0.2.2
kill -TERM "$pid"
wait "$pid"
pid=
if ip -n ll-a link show lla0 >/dev/null 2>&1 ||
   ip -n ll-b link show llb0 >/dev/null 2>&1; then
    echo 'TAP interface remained after process exit' >&2
    exit 1
fi
cat build/smoke.log
echo 'PASS: bidirectional ping, block/resume control, and graceful shutdown'
