#!/usr/bin/env python3
import gzip, hashlib, io, json, pathlib, tarfile
root = pathlib.Path(__file__).resolve().parents[1]
names = json.loads((root/'SOURCEFILES.json').read_text())['files']
files = {name: (root/name).read_bytes() for name in names}
files['SOURCEFILES.json'] = (json.dumps({'files': {n: hashlib.sha256(b).hexdigest() for n,b in sorted(files.items())}}, indent=2)+'\n').encode()
output = root/'build/release/platform-lab-source.tar.gz'
output.parent.mkdir(parents=True, exist_ok=True)
with output.open('wb') as stream, gzip.GzipFile(filename='', fileobj=stream, mode='wb', mtime=0) as gz, tarfile.open(fileobj=gz, mode='w', format=tarfile.PAX_FORMAT) as tar:
    for name, data in sorted(files.items()):
        info = tarfile.TarInfo('platform-lab-source/'+name)
        info.size, info.mtime, info.mode = len(data), 0, 0o755 if name.endswith('.sh') else 0o644
        tar.addfile(info, io.BytesIO(data))
print(str(output))
print('SHA256 '+hashlib.sha256(output.read_bytes()).hexdigest())
