#!/bin/sh
# Run only in a separately created privileged lab container/VM.
set -eu
cd "$(dirname "$0")/.."
mkdir -p build/network
CAPTURE_PCAP=/work/build/network/normal.pcap ./scripts/smoke.sh >build/network/normal.log 2>&1
LINK_DELAY_MS=100 ./scripts/smoke.sh >build/network/delay.log 2>&1
python3 - <<'PY'
from pathlib import Path
import re
s=Path('build/network/delay.log').read_text()
values=[float(x) for x in re.findall(r'time=([\d.]+) ms',s)]
assert values and min(values)>=190, values
print({'test':'two-way-monotonic-delay-100ms','min_rtt_ms':min(values),'result':'PASS'})
PY
ns=ll-local-contrast
if ip netns list | awk '{print $1}' | grep -qx "$ns"; then echo 'namespace exists, refusing' >&2; exit 1; fi
ip netns add "$ns"
trap 'ip netns del "$ns"' EXIT
ip -n "$ns" link set lo up
ip -n "$ns" addr add 192.0.2.1/24 dev lo
ip -n "$ns" addr add 192.0.2.2/24 dev lo
ip -n "$ns" route get 192.0.2.2 >build/network/local-route.txt
grep -q '^local ' build/network/local-route.txt
ip netns exec "$ns" ping -c 1 -W 1 192.0.2.2 >build/network/local-ping.txt
printf '%s\n' '{"test":"same-namespace-local-delivery","result":"PASS"}'
tcpdump -nr build/network/normal.pcap >build/network/frames.txt 2>&1
grep -q 'ARP' build/network/frames.txt
grep -q 'ICMP echo' build/network/frames.txt
printf '%s\n' '{"test":"ARP-ICMP-pcap","result":"PASS"}'
