#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
for ns in ll-drop-a ll-drop-b; do
 if ip netns list | awk '{print $1}' | grep -qx "$ns"; then echo 'existing namespace; refusing' >&2; exit 1; fi
done
for name in lldra0 lldrb0; do if ip link show "$name" >/dev/null 2>&1; then exit 1; fi; done
pid= receiver= ready= ready_dir= made_a=0 made_b=0
cleanup() {
 if [ -n "$ready" ]; then rm -f "$ready"; rmdir "$ready_dir"; fi
 if [ -n "$receiver" ]; then kill "$receiver" 2>/dev/null || true; wait "$receiver" 2>/dev/null || true; fi
 if [ -n "$pid" ]; then kill -TERM "$pid" 2>/dev/null || true; wait "$pid" 2>/dev/null || true; fi
 if [ "$made_a" = 1 ]; then ip netns del ll-drop-a; fi
 if [ "$made_b" = 1 ]; then ip netns del ll-drop-b; fi
}
trap cleanup EXIT
trap 'exit 130' INT
trap 'exit 143' TERM
make link
mkdir -p build/network
ip netns add ll-drop-a; made_a=1
ip netns add ll-drop-b; made_b=1
: >build/network/drop-link.log
./build/link-lab lldra0 lldrb0 --drop-a-every 2 --policy-ethertype 34997 >build/network/drop-link.log 2>&1 &
pid=$!
attempt=0
until grep -qx ready build/network/drop-link.log; do kill -0 "$pid"; attempt=$((attempt+1)); test "$attempt" -le 50; sleep 0.1; done
ip link set lldra0 netns ll-drop-a
ip link set lldrb0 netns ll-drop-b
ip -n ll-drop-a link set lldra0 up
ip -n ll-drop-b link set lldrb0 up
ready_dir=$(mktemp -d /tmp/platform-drop.XXXXXX)
ready=$ready_dir/ready
ip netns exec ll-drop-b python3 scripts/raw-frame-test.py receive lldrb0 "$ready" >build/network/drop-result.json &
receiver=$!
attempt=0
until test -f "$ready"; do kill -0 "$receiver"; attempt=$((attempt+1)); test "$attempt" -le 50; sleep 0.1; done
ip netns exec ll-drop-a python3 scripts/raw-frame-test.py send lldra0
wait "$receiver"; receiver=
kill -TERM "$pid"; wait "$pid"; pid=
cat build/network/drop-result.json
