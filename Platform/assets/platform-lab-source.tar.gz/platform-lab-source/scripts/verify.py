#!/usr/bin/env python3
"""Record command results and current source hashes for public experiments."""
import argparse, hashlib, json, pathlib, platform, subprocess, time
root = pathlib.Path(__file__).resolve().parents[1]
suites = {
 'user': [('make', 'test')],
 'startup': [('make', 'startup-test')],
 'reproduction': [('make', '-C', 'labs', 'all'), ('make', 'check-docs', 'package'), ('./build/labs/mechanisms', '--list'),
                  ('./build/labs/mechanisms', 'fd'), ('./build/labs/mechanisms', 'epoll'),
                  ('./build/labs/mechanisms', 'memory')],
 'freertos': [('make', 'freertos-test')],
 'network': [('make', 'integration')],
 'benchmark': [('make', '-C', 'platform', 'benchmark'), ('python3', 'scripts/benchmark-report.py')],
 'sanitize': [('make', '-C', 'platform', 'sanitize'), ('make', '-C', 'labs', 'sanitize'),
              ('make', 'STARTUP_BUILD=build/startup-asan', 'CFLAGS=-O1 -g -std=c11 -Wall -Wextra -Werror -fsanitize=address,undefined -fno-omit-frame-pointer', 'startup-test')],
 'tsan': [('make', '-C', 'platform', 'BUILD=../build/tsan', 'CFLAGS=-O1 -g -std=c11 -Wall -Wextra -Werror -fsanitize=thread', 'test'),
          ('make', 'STARTUP_BUILD=build/startup-tsan', 'CFLAGS=-O1 -g -std=c11 -Wall -Wextra -Werror -fsanitize=thread', 'startup-test')],
 'kernel-build': [('make', 'kernel-build')],
}
parser = argparse.ArgumentParser()
parser.add_argument('--suite', choices=suites, default='user')
args = parser.parse_args()
names = json.loads((root/'SOURCEFILES.json').read_text())['files']
hashes = {name: hashlib.sha256((root/name).read_bytes()).hexdigest() for name in names}
identity = hashlib.sha256(json.dumps(hashes, sort_keys=True).encode()).hexdigest()[:12]
run = root/'build/verification'/(time.strftime('%Y%m%d-%H%M%S')+'-'+identity+'-'+args.suite)
run.mkdir(parents=True, exist_ok=False)
record = {'suite': args.suite, 'source_id': identity, 'source_hashes': hashes,
          'environment': platform.uname()._asdict(), 'steps': []}
record['tool_versions'] = {}
for name, command in [('cc', ['cc', '--version']), ('make', ['make', '--version']),
                      ('python', ['python3', '--version']), ('libc', ['ldd', '--version'])]:
    result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=5)
    record['tool_versions'][name] = {'exit_code': result.returncode,
        'lines': result.stdout.decode(errors='replace').splitlines()[:3]}
for i, command in enumerate(suites[args.suite]):
    try:
        result = subprocess.run(command, cwd=root, stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT, timeout=300 if args.suite=='kernel-build' else 180)
        output, code = result.stdout, result.returncode
    except subprocess.TimeoutExpired as exc:
        output, code = exc.stdout or b'', 124
    log = f'{i:02d}.log'
    (run/log).write_bytes(output)
    skip = args.suite=='tsan' and b'ThreadSanitizer: unexpected memory mapping' in output
    state = 'SKIP' if skip else 'PASS' if code==0 else 'FAIL'
    record['steps'].append({'command': list(command), 'exit_code': code, 'status': state, 'log': log})
    print(json.dumps(record['steps'][-1]), flush=True)
    if state=='FAIL':
        print(output[-7000:].decode(errors='replace'), flush=True)
        break
record['result'] = 'FAIL' if any(s['status']=='FAIL' for s in record['steps']) else 'SKIP' if any(s['status']=='SKIP' for s in record['steps']) else 'PASS'
(run/'manifest.json').write_text(json.dumps(record, indent=2)+'\n')
print(str(run), flush=True)
raise SystemExit(1 if record['result']=='FAIL' else 0)
