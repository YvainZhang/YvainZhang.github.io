#!/usr/bin/env python3
import json
import pathlib
import socket
import struct
import sys
mode, interface = sys.argv[1:3]
sock = socket.socket(socket.AF_PACKET, socket.SOCK_RAW, socket.htons(0x88B5))
sock.bind((interface, 0))
if mode == 'send':
    for i in range(1, 7):
        frame = b'\xff'*6 + b'\x02\x00\x00\x00\x00\x01' + struct.pack('!HI', 0x88B5, i)
        sock.send(frame + b'\x00'*(60-len(frame)))
else:
    pathlib.Path(sys.argv[3]).write_text('ready\n')
    sock.settimeout(1)
    seen = []
    try:
        while True:
            frame = sock.recv(2048)
            seen.append(struct.unpack('!I', frame[14:18])[0])
    except socket.timeout:
        pass
    assert seen == [1, 3, 5], seen
    print(json.dumps({'test': 'deterministic-drop-every-2', 'received': seen, 'result': 'PASS'}))
sock.close()
